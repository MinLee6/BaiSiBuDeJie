//
//  LMMeFooterView.m
//  百思不得姐
//
//  Created by limin on 16/7/5.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMMeFooterView.h"
#import <AFNetworking.h>
#import "MBProgressHUD+LM.h"
#import <MJExtension.h>
#import "LMSquareModel.h"
#import <UIButton+WebCache.h>
#import "LMSquareButton.h"
#import "LMWebViewController.h"
#import "LMMeViewController.h"
@interface LMMeFooterView()
/* 数据数组 */
@property(nonatomic,strong)NSArray *squaresArray;
@end
@implementation LMMeFooterView

-(instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        
        self.backgroundColor = [UIColor whiteColor];
        [self loadNewData];
    }
    return self;
}
//设置背景图片
-(void)drawRect:(CGRect)rect
{
    [[UIImage imageNamed:@"mainCellBackground"]drawInRect:rect];
}
#pragma mark - 数据处理
-(void)loadNewData
{
    //参数
    NSMutableDictionary *para = [NSMutableDictionary dictionary];
    para[@"a"] = @"square";
    para[@"c"] = @"topic";
    
    //发送请求
    __weak LMMeFooterView *weakSelf = self;
    [[AFHTTPSessionManager manager] GET:@"http://api.budejie.com/api/api_open.php" parameters:para progress:^(NSProgress * _Nonnull downloadProgress) {
        //
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        //返回数据
        NSArray *squares = [LMSquareModel mj_objectArrayWithKeyValuesArray:responseObject[@"square_list"]];
        weakSelf.squaresArray = squares;
        [self createSqures:squares];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
      
        [MBProgressHUD showError:@"加载失败"];
       
    }];
}
#pragma mark - 创建方块
-(void)createSqures:(NSArray *)squares
{
    //一行最多4个。
    int maxCols = 4;
    
    //宽度、高度
    CGFloat width = LMScreenWidth / maxCols;
    CGFloat heght = width;
    for (int i=0; i<squares.count; i++) {
        
        //创建按钮
        LMSquareButton *btn = [LMSquareButton buttonWithType:UIButtonTypeCustom];
        btn.tag = 100 + i;
        // 监听点击
        [btn addTarget:self action:@selector(SquareBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        
        //传递模型
        btn.squareModel = squares[i];
        
        [self addSubview:btn];
        
        //计算frame
        int col = i % maxCols;
        int row = i / maxCols;
        btn.x = col*width;
        btn.y = row*heght;
        btn.width = width;
        btn.height = heght;
    }
    //计算整个footer的高度
    //总行数
//    NSUInteger rows = squares.count/maxCols;
//    
//    if (squares.count%4) {
//        rows++;
//    }
    
    NSUInteger rows = (squares.count + maxCols - 1)/maxCols;
    self.height = rows*heght;
    //取出当前的导航控制器
    UITabBarController *tabbarVC = (UITabBarController *)[UIApplication sharedApplication].keyWindow.rootViewController;
    
    UINavigationController *navVC = tabbarVC.selectedViewController;
    LMMeViewController *meVC = navVC.childViewControllers[0];
    meVC.footerView.height = self.height;
    NSLog(@"%@",navVC.childViewControllers[0]);
    //重绘
    [self setNeedsDisplay];
}
#pragma mark - 按钮点击事件
- (void)SquareBtnClick:(LMSquareButton *)button
{
    NSUInteger index = button.tag-100;
    LMSquareModel *model = self.squaresArray[index];
    
    //
    if (![model.url hasPrefix:@"http://"]) return;
    
    LMWebViewController *webVC = [[LMWebViewController alloc]init];
    webVC.title = model.name;
    webVC.urlStr = model.url;
    
    //取出当前的导航控制器
    UITabBarController *tabbarVC = (UITabBarController *)[UIApplication sharedApplication].keyWindow.rootViewController;
    
    UINavigationController *navVC = tabbarVC.selectedViewController;
    [navVC pushViewController:webVC animated:YES];
}

@end
