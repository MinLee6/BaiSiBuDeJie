//
//  LMSquareModel.h
//  百思不得姐
//
//  Created by limin on 16/7/5.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LMSquareModel : NSObject
/* 图标 */
@property(nonatomic,copy)NSString *icon;
/* 标题 */
@property(nonatomic,copy)NSString *name;
/* 链接 */
@property(nonatomic,copy)NSString *url;
@end
