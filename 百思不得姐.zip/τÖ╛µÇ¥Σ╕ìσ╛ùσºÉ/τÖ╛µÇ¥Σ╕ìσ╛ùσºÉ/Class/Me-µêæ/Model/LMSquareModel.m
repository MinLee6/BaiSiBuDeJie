//
//  LMSquareModel.m
//  百思不得姐
//
//  Created by limin on 16/7/5.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMSquareModel.h"

@implementation LMSquareModel

@end
