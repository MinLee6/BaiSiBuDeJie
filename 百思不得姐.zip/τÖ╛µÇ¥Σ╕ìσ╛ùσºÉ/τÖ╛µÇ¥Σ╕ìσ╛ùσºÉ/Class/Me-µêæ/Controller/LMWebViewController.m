//
//  LMWebViewController.m
//  百思不得姐
//
//  Created by limin on 16/7/6.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMWebViewController.h"
#import <NJKWebViewProgress.h>
@interface LMWebViewController ()<UIWebViewDelegate>
/** webview*/
@property (weak, nonatomic) IBOutlet UIWebView *webView;
/** 后退*/
@property (weak, nonatomic) IBOutlet UIBarButtonItem *gobackItem;
/** 前进*/
@property (weak, nonatomic) IBOutlet UIBarButtonItem *goforwardItem;
/* 进度代理对象 */
@property(nonatomic,strong)NJKWebViewProgress *progressProxy;
/** 进度条*/
@property (weak, nonatomic) IBOutlet UIProgressView *progressView;

@end

@implementation LMWebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _progressProxy = [[NJKWebViewProgress alloc] init];
    self.webView.delegate = _progressProxy;
    __weak LMWebViewController *weakSelf = self;
    _progressProxy.progressBlock = ^(float progress){
        weakSelf.progressView.progress = progress;
        weakSelf.progressView.hidden = (progress == 1.0);
    };
    self.progressProxy.webViewProxyDelegate = self;
    //private 私有API，搬过来用，不能通过审核。监听webview的真实进度，不允许监听。
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.urlStr]]];
    self.webView.delegate = self;
}
- (IBAction)refresh:(id)sender {
    [self.webView reload];
}
- (IBAction)goback:(id)sender {
    [self.webView goBack];
}
- (IBAction)goforward:(id)sender {
    [self.webView goForward];
}
#pragma mark - <UIWebViewDelegate>

-(void)webViewDidFinishLoad:(UIWebView *)webView
{
    self.gobackItem.enabled = webView.canGoBack;
    self.goforwardItem.enabled = webView.canGoForward;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
