//
//  LMMeViewController.m
//  百思不得姐
//
//  Created by limin on 16/6/14.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMMeViewController.h"
#import "LMMeTopCell.h"
#import "LMMeFooterView.h"
@interface LMMeViewController ()

@end

@implementation LMMeViewController
static NSString *cellID = @"MeCellID";
- (void)viewDidLoad {
    [super viewDidLoad];
    //设置导航
    [self setupNAV];
    //设置表
    [self setupTableView];
}
#pragma mark - 基本设置
-(void)setupNAV
{
    //设置导航标题
    self.navigationItem.title = @"我的";
    //设置右边的导航按钮
    UIBarButtonItem *settingItem = [UIBarButtonItem BarButtonItemWithImage:@"mine-setting-icon" highlightedImage:@"mine-setting-icon-click" target:self action:@selector(settingItemClick)];
    UIBarButtonItem *nightModeItem = [UIBarButtonItem BarButtonItemWithImage:@"mine-moon-icon" highlightedImage:@"mine-moon-icon-click" target:self action:@selector(nightModeItemClick)];
    
    self.navigationItem.rightBarButtonItems = @[settingItem,nightModeItem];
}
-(void)setupTableView
{
    //设置背景色
    self.tableView.backgroundColor = LMGlobalBg;
    
    //注册cell
    [self.tableView registerClass:[LMMeTopCell class] forCellReuseIdentifier:cellID];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    //调整header和footer
    self.tableView.sectionHeaderHeight = 0;
    self.tableView.sectionFooterHeight = LMTopicsCellMargin;
    
    //调整inset
    self.tableView.contentInset = UIEdgeInsetsMake(LMTopicsCellMargin-35, 0, 0, 0);
    
    //设置footerview
    LMMeFooterView *footerView = [[LMMeFooterView alloc]init];
    
    self.tableView.tableFooterView = footerView;
    self.footerView = footerView;

}

-(void)settingItemClick
{
    LMLogFunc;
}
-(void)nightModeItemClick
{
    LMLogFunc;
}
#pragma mark - <数据源方法>
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    LMMeTopCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (indexPath.section == 0) {
        cell.imageView.image = [UIImage imageNamed:@"mine-my-post"];
        cell.textLabel.text = @"登录/注册";
    }else if (indexPath.section == 1)
    {
        cell.textLabel.text = @"离线下载";
    }
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
