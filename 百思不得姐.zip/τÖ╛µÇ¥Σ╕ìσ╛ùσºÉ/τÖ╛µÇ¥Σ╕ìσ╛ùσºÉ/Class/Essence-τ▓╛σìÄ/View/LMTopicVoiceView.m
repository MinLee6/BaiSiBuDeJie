//
//  LMTopicVoiceView.m
//  百思不得姐
//
//  Created by limin on 16/6/28.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMTopicVoiceView.h"
#import "LMTopicsModel.h"
#import<UIImageView+WebCache.h>
#import <M13ProgressViewRing.h>
#import "LMShowPictureController.h"
@interface LMTopicVoiceView()
/* 图片 */
@property(nonatomic,weak)IBOutlet UIImageView *voiceImageView;
/* 播放次数 */
@property(nonatomic,weak)IBOutlet UILabel *playcountLabel;
/* 播放的总时长 */
@property(nonatomic,weak)IBOutlet UILabel *voicelengthLabel;
/* 播放按钮 */
//@property(nonatomic,weak)IBOutlet UIButton *playBtn;
@end
@implementation LMTopicVoiceView

/** 创建声音播放*/
+(instancetype)CreateTopicVoiceView
{
    return [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([LMTopicVoiceView class]) owner:self options:nil][0];
}
-(void)awakeFromNib
{
    [super awakeFromNib];
    //⚠️取消自动伸缩，图片尺寸已设定好，但变得很长，是因为自动布局的原因。
    self.autoresizingMask = UIViewAutoresizingNone;
    
    //给图片添加监听器
    self.voiceImageView.userInteractionEnabled = YES;
    [self.voiceImageView addGestureRecognizer:[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(showPicture)]];
    
}
-(void)showPicture
{
    LMShowPictureController *showPictureVC = [[LMShowPictureController alloc]init];
    showPictureVC.pictureModel = self.topicsVoice;
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:showPictureVC animated:YES completion:nil];
}
#pragma mark - 数据赋值
-(void)setTopicsVoice:(LMTopicsModel *)topicsVoice
{
    _topicsVoice = topicsVoice;
    //
    [self.voiceImageView sd_setImageWithURL:[NSURL URLWithString:topicsVoice.large_image]];
    
    self.playcountLabel.text = [NSString stringWithFormat:@"%zd播放",topicsVoice.playcount];
    
    //时长
    
    NSInteger minuted = topicsVoice.voicetime/60;
    NSInteger second = topicsVoice.voicetime%60;
    self.voicelengthLabel.text = [NSString stringWithFormat:@"%02zd:%02zd",minuted,second];
}
@end
