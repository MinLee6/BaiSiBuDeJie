//
//  LMTopicsCell.m
//  百思不得姐
//
//  Created by limin on 16/6/21.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMTopicsCell.h"
#import "LMTopicsModel.h"
#import "UIImageView+WebCache.h"
#import "NSDate+LMExtension.h"
#import "LMTopicPictureView.h"
#import "LMTopicVoiceView.h"
#import "LMTopicVideoView.h"
#import "LMCommentModel.h"
#import "LMUserModel.h"
@interface LMTopicsCell()
/** 头像*/
@property (weak, nonatomic) IBOutlet UIImageView *profileImageView;
/** 昵称*/
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
/** 创建时间*/
@property (weak, nonatomic) IBOutlet UILabel *createTimeLabel;
/** 顶*/
@property (weak, nonatomic) IBOutlet UIButton *dingButton;
/** 踩*/
@property (weak, nonatomic) IBOutlet UIButton *caiButton;
/** 分享*/
@property (weak, nonatomic) IBOutlet UIButton *shareButton;
/** 评论*/
@property (weak, nonatomic) IBOutlet UIButton *commentButton;
/** Vip用户*/
@property (weak, nonatomic) IBOutlet UIImageView *AddV_AuthenImageView;
/** 帖子的文字内容*/
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
/** 最热评论内容*/
@property (weak, nonatomic) IBOutlet UILabel *topCatContentLabel;
/** 最热评论的view*/
@property (weak, nonatomic) IBOutlet UIView *topCatView;

/* 图片帖子中间的内容view */
@property(nonatomic,weak)LMTopicPictureView *pictureView;
/* 声音帖子中间的内容view */
@property(nonatomic,weak)LMTopicVoiceView *voiceView;

/* 视频帖子中间的内容view */
@property(nonatomic,weak)LMTopicVideoView *videoView;
@end
@implementation LMTopicsCell
/** 创建TopicsCell*/
+(instancetype)createTopicsCell
{
    return [[NSBundle mainBundle]loadNibNamed:@"LMTopicsCell" owner:self options:nil][0];
}
-(LMTopicVideoView *)videoView
{
    if (!_videoView) {
        LMTopicVideoView *videoView = [LMTopicVideoView CreateTopicVideoView];
        [self.contentView addSubview:videoView];
        _videoView = videoView;
    }
    return _videoView;
}
-(LMTopicPictureView *)pictureView
{
    if (!_pictureView) {
        LMTopicPictureView *pictureView = [LMTopicPictureView CreateLMTopicPictureView];
        [self.contentView addSubview:pictureView];
        _pictureView = pictureView;
    }
    return _pictureView;
}
-(LMTopicVoiceView *)voiceView
{
    if (!_voiceView) {
        LMTopicVoiceView *voiceView = [LMTopicVoiceView CreateTopicVoiceView];
        [self.contentView addSubview:voiceView];
        _voiceView = voiceView;
    }
    return _voiceView;
}
- (void)awakeFromNib {
    [super awakeFromNib];
    UIImageView *bgView = [[UIImageView alloc]init];
    bgView.image = [UIImage imageNamed:@"mainCellBackground"];
    self.backgroundView = bgView;
    
    //图层裁剪，会导致程序很卡。
//    self.profileImageView.layer.cornerRadius = self.profileImageView.width * 0.5;
//    self.profileImageView.clipsToBounds = YES;
}
-(void)setTopicsModel:(LMTopicsModel *)topicsModel
{
    _topicsModel = topicsModel;
    
    [self.profileImageView setHeader:topicsModel.profile_image];
    //新浪加v显示
    self.AddV_AuthenImageView.hidden = !topicsModel.isSina_v;
    
    [self.nameLabel setText:topicsModel.name];
    [self setupCreateTime:topicsModel.create_time];
    //设置帖子的文字内容
    [self.contentLabel setText:topicsModel.text];
    //设置按钮文字
    [self setupBtnTitle:self.dingButton count:topicsModel.ding placeholder:@"顶"];
    [self setupBtnTitle:self.caiButton count:topicsModel.cai placeholder:@"踩"];
    [self setupBtnTitle:self.shareButton count:topicsModel.repost placeholder:@"分享"];
    [self setupBtnTitle:self.commentButton count:topicsModel.comment placeholder:@"评论"];
    
    //根据帖子的类型，添加内容到中间
    if (topicsModel.type == LMTopicsTypePicture) {
        self.pictureView.hidden = NO;
        self.voiceView.hidden = YES;
        self.videoView.hidden = YES;
        //图片路径
        //图片的宽度高度
        self.pictureView.topicsPicture = _topicsModel;
        self.pictureView.frame = _topicsModel.pictureFrame;
    }else if (topicsModel.type == LMTopicsTypeVoice)
    {
        self.pictureView.hidden = YES;
        self.voiceView.hidden = NO;
        self.videoView.hidden = YES;
        //图片路径
        self.voiceView.topicsVoice = _topicsModel;
//        //图片的宽度高度
        self.voiceView.frame = _topicsModel.voiceFrame;
    }else if (topicsModel.type == LMTopicsTypeVideo)
    {
        self.pictureView.hidden = YES;
        self.voiceView.hidden = YES;
        self.videoView.hidden = NO;
        //图片路径
        self.videoView.topicsVideo = _topicsModel;
        //        //图片的宽度高度
        self.videoView.frame = _topicsModel.videoFrame;
    }else//段子帖子
    {
        self.pictureView.hidden = YES;
        self.voiceView.hidden = YES;
        self.videoView.hidden = YES;
    }
        
   //处理最热评论
    LMCommentModel *cmt = [topicsModel.top_cmt firstObject];
    if (cmt) {
        self.topCatView.hidden = NO;
        self.topCatContentLabel.text = [NSString stringWithFormat:@"%@ : %@",cmt.user.username,cmt.content];
    }else
    {
        self.topCatView.hidden = YES;
    }
    
}
#pragma mark - 时间处理
/**
 *self.createTimeLabel:时间标签
 *今天：
 [
 1分钟内：刚刚
 1小时内：xx分钟前
 其他：xx小时前
 ]
 *昨天：几点几分
 *其他：6-13 19：12
 *不是今年：去年：年份2014-5-8 18:40:30
 */
-(void)setupCreateTime:(NSString *)create_time
{
    
    //设置日期格式
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    //创建时间
    NSDate *createDate = [formatter dateFromString:create_time];
    
    
    if (createDate.isThisYear) {//今年
        
        if (createDate.isToday) {//今天
            
            //当前时间
            NSDate *nowDate = [NSDate date];
            //比较时间
            NSDateComponents *comps = [nowDate deltaFrom:createDate];
            if (comps.hour >= 1) {
                //时间差距>=1小时
                [self.createTimeLabel setText:[NSString stringWithFormat:@"%zd小时前",comps.hour]];
            }else if (comps.minute >= 1)
            {
                //时间差距<1小时,>＝1分钟
               [self.createTimeLabel setText:[NSString stringWithFormat:@"%zd分钟前",comps.minute]];
            }else
            {// 时间差距<1分钟
                [self.createTimeLabel setText:@"刚刚"];
            }
            
            
        }else if (createDate.isYesterday)//昨天
        {
            formatter.dateFormat = @"昨天 HH:mm:ss";
            [self.createTimeLabel setText:[formatter stringFromDate:createDate]];
        }else
        {//其他
            formatter.dateFormat = @"MM-dd HH:mm:ss";
            [self.createTimeLabel setText:[formatter stringFromDate:createDate]];
        }
    }else//非今年
    {
        [self.createTimeLabel setText:create_time];
    }
    
}

#pragma mark - 设置按钮文字
-(void)setupBtnTitle:(UIButton *)button count:(NSInteger)count placeholder:(NSString *)placeholder
{
    if(count>10000)
    {
        placeholder = [NSString stringWithFormat:@"%.1f万",count/10000.0];
    }else if (count > 0)
    {
        placeholder = [NSString stringWithFormat:@"%zd",count];
    }
    [button setTitle:placeholder forState:UIControlStateNormal];
}
-(void)setFrame:(CGRect)frame
{
    frame.origin.x = LMTopicsCellMargin;
    frame.origin.y += LMTopicsCellMargin;
    frame.size.width -= LMTopicsCellMargin*2;
//    frame.size.height -= LMTopicsCellMargin;
    frame.size.height = self.topicsModel.cellHeight - LMTopicsCellMargin;
    [super setFrame:frame];
}
- (IBAction)moreBtnClick:(UIButton *)sender {
    
    UIActionSheet *sheet = [[UIActionSheet alloc]initWithTitle:nil delegate:nil cancelButtonTitle:@"取消" destructiveButtonTitle: nil otherButtonTitles:@"举报",@"收藏", nil];
    [sheet showInView:self.window];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
