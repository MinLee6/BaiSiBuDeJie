//
//  LMCommentCell.h
//  百思不得姐
//
//  Created by limin on 16/6/30.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LMCommentModel;
@interface LMCommentCell : UITableViewCell
/** 评论数据*/
@property(nonatomic,strong)LMCommentModel *commentModel;
@end
