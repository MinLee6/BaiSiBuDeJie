//
//  LMTopicVideoView.m
//  百思不得姐
//
//  Created by limin on 16/6/28.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMTopicVideoView.h"
#import "LMTopicsModel.h"
#import<UIImageView+WebCache.h>
#import <M13ProgressViewRing.h>
#import "LMShowPictureController.h"
@interface LMTopicVideoView()
/* 图片 */
@property(nonatomic,weak)IBOutlet UIImageView *videoImageView;

@end
@implementation LMTopicVideoView

/** 创建声音播放*/
+(instancetype)CreateTopicVideoView
{
    return [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([LMTopicVideoView class]) owner:self options:nil][0];
}
-(void)awakeFromNib
{
    [super awakeFromNib];
    //⚠️取消自动伸缩，图片尺寸已设定好，但变得很长，是因为自动布局的原因。
    self.autoresizingMask = UIViewAutoresizingNone;
    
    //给图片添加监听器
    self.videoImageView.userInteractionEnabled = YES;
    [self.videoImageView addGestureRecognizer:[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(showPicture)]];
    
}
-(void)showPicture
{
    LMShowPictureController *showPictureVC = [[LMShowPictureController alloc]init];
    showPictureVC.pictureModel = self.topicsVideo;
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:showPictureVC animated:YES completion:nil];
}
#pragma mark - 数据赋值
-(void)setTopicsVideo:(LMTopicsModel *)topicsVideo
{
    _topicsVideo = topicsVideo;
    //背景图片
    [self.videoImageView sd_setImageWithURL:[NSURL URLWithString:topicsVideo.large_image]];
    
}
@end
