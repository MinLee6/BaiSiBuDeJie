//
//  LMCommentHeaderView.h
//  百思不得姐
//
//  Created by limin on 16/6/30.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LMCommentHeaderView : UITableViewHeaderFooterView
/* 文字数据 */
@property(nonatomic,copy)NSString *titleStr;

+(instancetype)headerViewWithTableView:(UITableView *)tableView;
@end
