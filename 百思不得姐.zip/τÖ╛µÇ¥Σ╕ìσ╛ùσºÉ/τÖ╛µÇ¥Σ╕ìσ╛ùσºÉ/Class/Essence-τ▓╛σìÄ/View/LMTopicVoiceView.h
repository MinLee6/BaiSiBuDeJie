//
//  LMTopicVoiceView.h
//  百思不得姐
//
//  Created by limin on 16/6/28.
//  Copyright © 2016年 limin. All rights reserved.
//声音帖子中间的view

#import <UIKit/UIKit.h>
@class LMTopicsModel;

@interface LMTopicVoiceView : UIView
/** 创建声音播放*/
+(instancetype)CreateTopicVoiceView;

/* 数据模型 */
@property(nonatomic,strong)LMTopicsModel *topicsVoice;
@end
