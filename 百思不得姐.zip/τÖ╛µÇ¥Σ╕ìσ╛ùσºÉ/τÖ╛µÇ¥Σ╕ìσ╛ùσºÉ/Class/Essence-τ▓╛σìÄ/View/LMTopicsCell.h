//
//  LMTopicsCell.h
//  百思不得姐
//
//  Created by limin on 16/6/21.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LMTopicsModel;
@interface LMTopicsCell : UITableViewCell
/* 数据模型 */
@property(nonatomic,strong)LMTopicsModel *topicsModel;
/** 创建TopicsCell*/
+(instancetype)createTopicsCell;
@end
