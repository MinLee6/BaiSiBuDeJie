
//
//  LMCommentHeaderView.m
//  百思不得姐
//
//  Created by limin on 16/6/30.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMCommentHeaderView.h"
static NSInteger const LMHeaderLabelTag = 99;
@interface LMCommentHeaderView()
/* 标签 */
@property(nonatomic,weak)UILabel *label;
@end
@implementation LMCommentHeaderView

-(instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithReuseIdentifier:reuseIdentifier]) {
        self.contentView.backgroundColor = LMGlobalBg;
        //创建label
        UILabel *label = [[UILabel alloc]init];
        label.width = 200;
        label.x = LMTopicsCellMargin;
        label.autoresizingMask = UIViewAutoresizingFlexibleHeight;
        label.textColor = LMRGB(67, 67, 67);
        [label setFont:[UIFont systemFontOfSize:12]];
        label.tag = LMHeaderLabelTag;
        [self.contentView addSubview:label];
        
        self.label = label;
    }
    return self;
}
+(instancetype)headerViewWithTableView:(UITableView *)tableView
{
    static NSString *headerID = @"headerID";
    //先从缓存池中找header
    LMCommentHeaderView *header = [tableView dequeueReusableHeaderFooterViewWithIdentifier:headerID];
    
    if (!header) {//缓存池中没有，自己创建
        header = [[LMCommentHeaderView alloc]initWithReuseIdentifier:headerID];
    }
    return header;
}
-(void)setTitleStr:(NSString *)titleStr
{
    _titleStr = [titleStr copy];
    self.label.text = titleStr;
    
}
@end
