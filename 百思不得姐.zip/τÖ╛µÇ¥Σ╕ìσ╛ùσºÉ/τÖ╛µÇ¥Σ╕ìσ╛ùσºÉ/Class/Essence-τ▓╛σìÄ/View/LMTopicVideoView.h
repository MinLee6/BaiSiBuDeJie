//
//  LMTopicVideoView.h
//  百思不得姐
//
//  Created by limin on 16/6/28.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LMTopicsModel;

@interface LMTopicVideoView : UIView
/** 创建声音播放*/
+(instancetype)CreateTopicVideoView;

/* 数据模型 */
@property(nonatomic,strong)LMTopicsModel *topicsVideo;
@end