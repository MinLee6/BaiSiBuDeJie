//
//  LMTopicPictureView.m
//  百思不得姐
//
//  Created by limin on 16/6/23.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMTopicPictureView.h"
#import "LMTopicsModel.h"
#import<UIImageView+WebCache.h>
#import "LMShowPictureController.h"
#import <M13ProgressViewRing.h>
@interface LMTopicPictureView()
/* 图片 */
@property(nonatomic,weak)IBOutlet UIImageView *imageView;
/* gif图片 */
@property(nonatomic,weak)IBOutlet UIImageView *gifImageView;
/* 查看大图按钮 */
@property(nonatomic,weak)IBOutlet UIButton *seeBigButton;
/* 进度条控件 */
@property (weak, nonatomic) IBOutlet M13ProgressViewRing *progressView;
@end
@implementation LMTopicPictureView

+(instancetype)CreateLMTopicPictureView
{
    return [[NSBundle mainBundle]loadNibNamed:NSStringFromClass([LMTopicPictureView class]) owner:self options:nil][0];
}
-(void)awakeFromNib
{
    [super awakeFromNib];
    //⚠️取消自动伸缩，图片尺寸已设定好，但变得很长，是因为自动布局的原因。
    self.autoresizingMask = UIViewAutoresizingNone;
    
    //给图片添加监听器
    self.imageView.userInteractionEnabled = YES;
    [self.imageView addGestureRecognizer:[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(showPicture)]];
    
}
-(void)showPicture
{
    LMShowPictureController *showPictureVC = [[LMShowPictureController alloc]init];
    showPictureVC.pictureModel = self.topicsPicture;
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:showPictureVC animated:YES completion:nil];
}
-(void)setTopicsPicture:(LMTopicsModel *)topicsPicture
{
    _topicsPicture = topicsPicture;
    //防止因为网速慢，显示的是别的cell的加载进度.
    [self.progressView setProgress:topicsPicture.pictureProgress animated:NO];
    //GIF自动播放原理：SDWebImage利用ImageIO框架-GIF-N个UIImage。iOS不支持gif图片播放。再利用这个self.imageView.animationImages播放。
    //设置图片
    [self.imageView sd_setImageWithURL:[NSURL URLWithString:_topicsPicture.large_image] placeholderImage:nil options:0 progress:^(NSInteger receivedSize, NSInteger expectedSize) {
        self.progressView.hidden = NO;
        
        //计算加载进度值
        _topicsPicture.pictureProgress = 1.0*receivedSize/expectedSize;
        [self.progressView setProgress:_topicsPicture.pictureProgress animated:NO];
        
    } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        
        self.progressView.hidden = YES;
        //如果是大图，才需要进行绘图处理.
        if (topicsPicture.isBigPicture == NO) return ;
        
        //开启图形上下文
        UIGraphicsBeginImageContextWithOptions(topicsPicture.pictureFrame.size, YES, 0.0);
        //将下载完的图像，绘制到图形上下文中
        CGFloat width = topicsPicture.pictureFrame.size.width;
        //图片宽度，图片高度
        CGFloat height = width * image.size.height / image.size.width;
        [image drawInRect:CGRectMake(0, 0, width, height)];
        //获取图片
        self.imageView.image = UIGraphicsGetImageFromCurrentImageContext();
        //结束图形上下文.
        UIGraphicsEndImageContext();
    }];

    
    /**
     *在不知道图片扩展名的情况下，取出图片的第一个字节，就可以判断出图片的真实类型
     */
    //判断是否为gif图片
    NSString *extension = _topicsPicture.large_image.pathExtension;
    self.gifImageView.hidden = ![extension.lowercaseString isEqualToString:@"gif"];

    //判断是否显示：“点击查看全图”
    if (topicsPicture.bigPicture) {//大图
        self.seeBigButton.hidden = NO;
        //并勾选xib中clip subviews
        self.imageView.contentMode = UIViewContentModeScaleAspectFill;
    }else//小图
    {
        self.seeBigButton.hidden = YES;
        self.imageView.contentMode = UIViewContentModeScaleToFill;
    }
    
}
@end
