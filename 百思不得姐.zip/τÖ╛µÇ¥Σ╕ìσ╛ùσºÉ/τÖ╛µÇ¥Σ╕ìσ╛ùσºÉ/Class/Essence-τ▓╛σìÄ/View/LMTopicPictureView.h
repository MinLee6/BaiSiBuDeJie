//
//  LMTopicPictureView.h
//  百思不得姐
//
//  Created by limin on 16/6/23.
//  Copyright © 2016年 limin. All rights reserved.
//图片帖子中间的view

#import <UIKit/UIKit.h>
@class LMTopicsModel;
@interface LMTopicPictureView : UIView
/** 创建PictureView*/
+(instancetype)CreateLMTopicPictureView;
/* 数据模型 */
@property(nonatomic,strong)LMTopicsModel *topicsPicture;
@end
