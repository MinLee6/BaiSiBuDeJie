//
//  LMCommentCell.m
//  百思不得姐
//
//  Created by limin on 16/6/30.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMCommentCell.h"
#import "LMCommentModel.h"
#import "UIImageView+WebCache.h"
#import "LMUserModel.h"
@interface LMCommentCell()
/* 头像 */
@property(nonatomic,weak)IBOutlet UIImageView *profileImageView;
/** 性别图片*/
@property (weak, nonatomic) IBOutlet UIImageView *sexImageView;
/** 用户名*/
@property (weak, nonatomic) IBOutlet UILabel *usernameLabel;
/** 内容*/
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
/** 点赞数量*/
@property (weak, nonatomic) IBOutlet UILabel *likeCountLabel;
/** 音频按钮*/
@property (weak, nonatomic) IBOutlet UIButton *voiceButton;

@end
@implementation LMCommentCell
//-(void)setFrame:(CGRect)frame
//{
//    frame.origin.x = LMTopicsCellMargin;
//    frame.size.width -=2*LMTopicsCellMargin;
//    [super setFrame:frame];
//}
- (void)awakeFromNib {
    [super awakeFromNib];
    UIImageView *bgView = [[UIImageView alloc]init];
    bgView.image = [UIImage imageNamed:@"mainCellBackground"];
    self.backgroundView = bgView;
}
-(void)setCommentModel:(LMCommentModel *)commentModel
{
    _commentModel = commentModel;
    
    //设置头像
    [self.profileImageView setHeader:commentModel.user.profile_image];
    
    self.sexImageView.image = [commentModel.user.sex isEqualToString:LMUserModelSexMale] ? [UIImage imageNamed:@"Profile_manIcon"]:[UIImage imageNamed:@"Profile_womanIcon"];
    
    self.contentLabel.text = commentModel.content;
    self.usernameLabel.text = commentModel.user.username;
    self.likeCountLabel.text = [NSString stringWithFormat:@"%zd",commentModel.like_count];
    
    //
    if (commentModel.voiceuri.length) {
        //
        self.voiceButton.hidden = NO;
        
        [self.voiceButton setTitle:[NSString stringWithFormat:@"%zd''",commentModel.voicetime] forState:UIControlStateNormal];
        self.contentLabel.hidden = YES;
    }else
    {
        self.voiceButton.hidden = YES;
        self.contentLabel.hidden = NO;
    }
}
#pragma mark - UIMenuController处理
-(BOOL)canBecomeFirstResponder
{
    return YES;
}
-(BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
    return NO;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
