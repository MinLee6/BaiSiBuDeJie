//
//  LMRecommendTagsCell.m
//  百思不得姐
//
//  Created by limin on 16/6/16.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMRecommendTagsCell.h"
#import "LMRecommendTags.h"
#import <UIImageView+WebCache.h>
@interface LMRecommendTagsCell()
@property (weak, nonatomic) IBOutlet UIImageView *image_listImageView;
@property (weak, nonatomic) IBOutlet UILabel *theme_nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *sub_numberLabel;
@end
@implementation LMRecommendTagsCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
-(void)setTagsModel:(LMRecommendTags *)tagsModel
{
    _tagsModel = tagsModel;
    //
    self.theme_nameLabel.text = tagsModel.theme_name;
    
    //设置头像
    [self.image_listImageView setHeader:tagsModel.image_list];
    NSString *subNumber = nil;
    if (tagsModel.sub_number < 10000) {
        subNumber = [NSString stringWithFormat:@"%zd人订阅",tagsModel.sub_number];
    }else
    {
        //大于等于1万
        subNumber = [NSString stringWithFormat:@"%.1f万人订阅",tagsModel.sub_number/10000.0];
    }
    self.sub_numberLabel.text = subNumber;
}
-(void)setFrame:(CGRect)frame
{
    //    LMLog(@"%@",NSStringFromCGRect(frame));
    //修改X值。
    frame.origin.x = 5;
    frame.size.width -=2*frame.origin.x;
    frame.size.height -= 1;
    [super setFrame:frame];

}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
