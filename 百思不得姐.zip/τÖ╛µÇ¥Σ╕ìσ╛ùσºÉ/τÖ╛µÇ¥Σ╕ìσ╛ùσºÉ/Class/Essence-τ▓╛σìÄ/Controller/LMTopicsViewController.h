//
//  LMTopicsViewController.h
//  百思不得姐
//
//  Created by limin on 16/6/22.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LMTopicsViewController : UITableViewController
/* 帖子类型 */
@property(nonatomic,assign)LMTopicsType type;
@end
