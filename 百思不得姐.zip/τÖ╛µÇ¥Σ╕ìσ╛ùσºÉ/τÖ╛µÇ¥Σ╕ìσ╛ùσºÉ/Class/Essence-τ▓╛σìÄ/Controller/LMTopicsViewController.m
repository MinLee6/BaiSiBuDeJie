//
//  LMWordTableController.m
//  百思不得姐
//
//  Created by limin on 16/6/22.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMTopicsViewController.h"
#import <AFNetworking.h>
#import "MBProgressHUD+LM.h"
#import "UIImageView+WebCache.h"
#import "LMTopicsModel.h"
#import "MJExtension.h"
#import "MJRefresh.h"
#import "LMTopicsCell.h"
#import "LMCommentViewController.h"
#import "LMNewViewController.h"
@interface LMTopicsViewController ()
/* 帖子数据 */
@property(nonatomic,strong)NSMutableArray *topicsArray;
/* 当前页码 */
@property(nonatomic,assign)NSInteger page;
/* 当加载下一页数据需要改参数 */
@property(nonatomic,copy)NSString *maxtime;
/* 上一次请求的参数 */
@property(nonatomic,strong)NSDictionary *params;
/* 上次选中的索引 */
@property(nonatomic,assign)NSInteger lastSelectedIndex;
@end

@implementation LMTopicsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //初始化表格
    [self setupTableView];
    //添加刷新控件
    [self setupRefresh];
    
    
}
static NSString *const LMTopicsCellID = @"TopicsCell";
-(void)setupTableView
{
    //设置内边距
    CGFloat bottom = self.tabBarController.tabBar.height+LMTitleViewH+LMTitleViewY;
    self.tableView.contentInset = UIEdgeInsetsMake(0, 0, bottom,0);
    self.tableView.scrollIndicatorInsets = self.tableView.contentInset;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.backgroundColor = [UIColor clearColor];
    //注册
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([LMTopicsCell class]) bundle:nil] forCellReuseIdentifier:LMTopicsCellID];
    
    //监听tabbar点击的通知
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(tabBarClick) name:LMTabBarDidSelectedNotification object:nil];
}
#pragma mark - 通知，Tabbar点击事件
-(void)tabBarClick
{
    //当前view在window上，并且能看的见
    //如果选中的不是当前的导航控制器，直接返回；
    //如果不是连续选中2次，直接返回；
    if(self.lastSelectedIndex == self.tabBarController.selectedIndex && self.tabBarController.selectedViewController == self.navigationController && self.view.isShowingOnKeyWindow){
         [self.tableView.mj_header beginRefreshing];
    }
    //记住这一次选中的索引
    self.lastSelectedIndex = self.tabBarController.selectedIndex;
   
}
-(NSMutableArray *)topicsArray
{
    if (!_topicsArray) {
        _topicsArray = [NSMutableArray array];
    }
    return _topicsArray;
}
#pragma mark - 添加刷新控件
-(void)setupRefresh
{
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadNewTopics)];
    
    //根据拖拽比例自动切换透明度
    [self.tableView.mj_header setAutomaticallyChangeAlpha:YES];
    [self.tableView.mj_header beginRefreshing];
    
    //自动刷新 MJRefreshBackNormalFooter(自己拖拽出来，不需要隐藏)
    self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreTopics)];
    //    self.tableView.mj_footer.hidden = YES;
}
#pragma mark - a参数
-(NSString *)a
{
    return [self.parentViewController isKindOfClass:[LMNewViewController class]]?@"newlist":@"list";
  
}
#pragma mark - 数据处理
-(void)loadNewTopics
{
    //结束上拉刷新
    [self.tableView.mj_footer endRefreshing];
    
    //参数
    NSMutableDictionary *para = [NSMutableDictionary dictionary];
    para[@"a"] = self.a;
    para[@"c"] = @"data";
    para[@"type"] = @(self.type);
    self.params = para;
    //发送请求
    [[AFHTTPSessionManager manager] GET:@"http://api.budejie.com/api/api_open.php" parameters:para progress:^(NSProgress * _Nonnull downloadProgress) {
        //
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        //请求过期
        if (self.params != para) return;
        
        
        
        //存储maxtime
        self.maxtime = responseObject[@"info"][@"maxtime"];
        self.topicsArray = [LMTopicsModel mj_objectArrayWithKeyValuesArray:responseObject[@"list"]];
        [self.tableView reloadData];
        //结束刷新
        [self.tableView.mj_header endRefreshing];
        //清空页码
        self.page = 0;
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [self.tableView.mj_header endRefreshing];
        [MBProgressHUD showError:@"加载失败"];
        //请求过期
        if (self.params != para) return;
        
    }];
}
//先下拉刷新，再上拉刷新第五页的数据

//下拉刷新成功回来；只有一页数据，page ＝ 0；
//上拉刷新成功回来。

/**
 *加载更多的帖子
 */
-(void)loadMoreTopics
{
    //结束上拉刷新
    [self.tableView.mj_header endRefreshing];
    
    NSInteger page = self.page+1;
    //参数
    NSMutableDictionary *para = [NSMutableDictionary dictionary];
    para[@"a"] = self.a;
    para[@"c"] = @"data";
    para[@"type"] = @(self.type);
    para[@"page"] = @(page);
    para[@"maxtime"] = self.maxtime;
    self.params = para;
    //发送请求
    [[AFHTTPSessionManager manager] GET:@"http://api.budejie.com/api/api_open.php" parameters:para progress:^(NSProgress * _Nonnull downloadProgress) {
        //
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if(self.params != para) return;
        //存储maxtime
        self.maxtime = responseObject[@"info"][@"maxtime"];
        //字典->模型
        NSArray *temp = [LMTopicsModel mj_objectArrayWithKeyValuesArray:responseObject[@"list"]];
        [self.topicsArray addObjectsFromArray:temp];
        [self.tableView reloadData];
        //结束刷新
        [self.tableView.mj_footer endRefreshing];
        //设置页码
        self.page = page;
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if(self.params != para) return;
        
        [self.tableView.mj_footer endRefreshing];
        [MBProgressHUD showError:@"加载失败"];
        
    }];
}
#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    self.tableView.mj_footer.hidden = (self.topicsArray.count == 0);
    return self.topicsArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    LMTopicsCell *topicsCell = [tableView dequeueReusableCellWithIdentifier:LMTopicsCellID];
    LMTopicsModel *model = self.topicsArray[indexPath.row];
    topicsCell.topicsModel = model;
    return topicsCell;
}
#pragma mark - tableview delegate
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //取出帖子模型
    LMTopicsModel *model = self.topicsArray[indexPath.row];
    
    return model.cellHeight;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    LMCommentViewController *commentVC = [[LMCommentViewController alloc]init];
    
    commentVC.topicsComment = self.topicsArray[indexPath.row];
    [self.navigationController pushViewController:commentVC animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
