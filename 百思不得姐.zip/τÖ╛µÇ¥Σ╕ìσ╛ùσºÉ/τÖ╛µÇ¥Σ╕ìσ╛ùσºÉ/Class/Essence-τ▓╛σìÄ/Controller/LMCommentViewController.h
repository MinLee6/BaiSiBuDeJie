//
//  LMCommentViewController.h
//  百思不得姐
//
//  Created by limin on 16/6/29.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LMTopicsModel;
@interface LMCommentViewController : UIViewController
/* 数据模型 */
@property(nonatomic,strong)LMTopicsModel *topicsComment;
@end
