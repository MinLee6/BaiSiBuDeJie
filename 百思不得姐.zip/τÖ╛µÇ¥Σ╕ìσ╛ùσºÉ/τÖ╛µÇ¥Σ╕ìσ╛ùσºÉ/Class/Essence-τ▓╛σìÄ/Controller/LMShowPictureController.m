//
//  LMShowPictureController.m
//  百思不得姐
//
//  Created by limin on 16/6/23.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMShowPictureController.h"
#import "LMTopicsModel.h"
#import <UIImageView+WebCache.h>
#import "MBProgressHUD+LM.h"
#import <M13ProgressViewRing.h>
@interface LMShowPictureController ()
/* 图片 */
@property(nonatomic,weak) UIImageView *imageView;
/* scrollview */
@property(nonatomic,weak)IBOutlet UIScrollView *scrollView;
/* 进度条控件 */
@property (weak, nonatomic) IBOutlet M13ProgressViewRing *progressView;
@end

@implementation LMShowPictureController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //添加图片
    UIImageView *imageView = [[UIImageView alloc]init];
    imageView.userInteractionEnabled = YES;
    [imageView addGestureRecognizer:[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(backBtnClick)] ];
    [self.scrollView addSubview:imageView];
    self.imageView = imageView;
    
    //显示图片的尺寸
    CGFloat pictureW = LMScreenWidth;
    CGFloat pictureH = pictureW*self.pictureModel.height/self.pictureModel.width;
    if (pictureH>LMScreenHeight) {//图片显示高度超过一个屏幕，需要滚动查看
        self.imageView.frame = CGRectMake(0, 0, pictureW, pictureH);
        self.scrollView.contentSize = CGSizeMake(0, pictureH);
    }else//居中显示
    {
        self.imageView.size = CGSizeMake(pictureW, pictureH);
        self.imageView.centerY = LMScreenHeight * 0.5;
        self.imageView.centerX = LMScreenWidth * 0.5;
    }
    //立马显示最新的进度值
    [self.progressView setProgress:self.pictureModel.pictureProgress animated:NO];
    
    [self.imageView sd_setImageWithURL:[NSURL URLWithString:self.pictureModel.large_image] placeholderImage:nil options:0 progress:^(NSInteger receivedSize, NSInteger expectedSize) {
        
        CGFloat progressValue = 1.0*receivedSize/expectedSize;
        [self.progressView setProgress:progressValue animated:NO];
    } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        self.progressView.hidden = YES;
    }];
}
#pragma mark - 返回
- (IBAction)backBtnClick {
    [self dismissViewControllerAnimated:YES completion:nil];
}
#pragma mark - 保存
- (IBAction)saveBtnClick {
    if (self.imageView.image == nil) {
        [MBProgressHUD showError:@"图片并未下载完毕!"];
        return;
    }
    //写到保存的图片相册中
    //第一次掉用时，会弹框提示用户.
    UIImageWriteToSavedPhotosAlbum(self.imageView.image, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);
}
//保存完成后
- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    if (error) {
        [MBProgressHUD showError:@"保存失败!"];
    }else
    {
        [MBProgressHUD showSuccess:@"保存成功!"];
    }
    
}
#pragma mark - 转发
- (IBAction)shareBtnClick {
   
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
