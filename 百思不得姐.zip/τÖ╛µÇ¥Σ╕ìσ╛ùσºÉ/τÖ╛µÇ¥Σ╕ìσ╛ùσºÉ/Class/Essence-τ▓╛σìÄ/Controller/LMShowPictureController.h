//
//  LMShowPictureController.h
//  百思不得姐
//
//  Created by limin on 16/6/23.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LMTopicsModel;
@interface LMShowPictureController : UIViewController
/* 数据模型 */
@property(nonatomic,weak)LMTopicsModel *pictureModel;
@end
