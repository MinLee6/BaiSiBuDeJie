//
//  LMRecommendTagsController.m
//  百思不得姐
//
//  Created by limin on 16/6/16.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMRecommendTagsController.h"
#import <AFNetworking.h>
#import "MBProgressHUD+LM.h"
#import "LMRecommendTags.h"
#import "MJExtension.h"
#import "LMRecommendTagsCell.h"
@interface LMRecommendTagsController ()
/* 标签数据 */
@property(nonatomic,strong)NSArray *tags;
@end
static NSString *LMTagsID = @"RecommendTags";
@implementation LMRecommendTagsController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"推荐标签";
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([LMRecommendTagsCell class]) bundle:nil] forCellReuseIdentifier:LMTagsID];
    self.tableView.rowHeight = 70;
    self.tableView.backgroundColor = LMGlobalBg;
    //显示指示器
    [MBProgressHUD showMessage:@"加载中..." toView:self.view];
    NSDictionary *dict = @{@"a":@"tag_recommend",@"action":@"sub",@"c":@"topic"};
    [[AFHTTPSessionManager manager]GET:@"http://api.budejie.com/api/api_open.php" parameters:dict progress:^(NSProgress * _Nonnull downloadProgress) {
        //
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
//        LMLog(@"%@",responseObject);
        NSArray *tags = [LMRecommendTags mj_objectArrayWithKeyValuesArray:responseObject];
        self.tags = tags;
        [self.tableView reloadData];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        [MBProgressHUD showError:@"加载推荐失败"];

    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.tags.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    LMRecommendTagsCell *cell = [tableView dequeueReusableCellWithIdentifier:LMTagsID];
    cell.tagsModel = self.tags[indexPath.row];
    return cell;
}


@end
