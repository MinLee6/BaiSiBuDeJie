//
//  LMEssenceViewController.m
//  百思不得姐
//
//  Created by limin on 16/6/14.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMEssenceViewController.h"
#import "LMRecommendTagsController.h"
#import "LMTopicsViewController.h"
@interface LMEssenceViewController ()<UIScrollViewDelegate>
/* 底部的红色指示器 */
@property(nonatomic,weak)UIView *indictor;
/* 当前选中的按钮 */
@property(nonatomic,weak)UIButton *selectedBtn;
/* 顶部的标签 */
@property(nonatomic,weak)UIView *titlesView;
/* scrollView */
@property(nonatomic,weak)UIScrollView *contentView;
@end

@implementation LMEssenceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 设置导航栏的内容
    [self setupNav];
    //初始化自控制器
    [self setupChildViews];
    //底部的uiscrollview
    [self setupContentView];
    
    //设置顶部的标题
    [self setupTitleView];
    
    
}
#pragma mark - 设置导航栏的内容
-(void)setupNav
{
    //设置背景色
    self.view.backgroundColor = LMGlobalBg;
    //设置导航栏标题
    self.navigationItem.titleView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"MainTitle"]];
    //左边的导航项
    
    self.navigationItem.leftBarButtonItem = [UIBarButtonItem BarButtonItemWithImage:@"MainTagSubIcon" highlightedImage:@"MainTagSubIconClick" target:self action:@selector(essenceButtonClick)];
    
}
#pragma mark - 设置顶部的标题
-(void)setupTitleView
{
    UIView *titlesView = [[UIView alloc]initWithFrame:CGRectMake(0,LMTitleViewY, self.view.bounds.size.width, LMTitleViewH)];
    titlesView.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.5];
    self.titlesView = titlesView;
    //底部的红色指示器
    UIView *indictor = [[UIView alloc]init];
    indictor.height = 2;
    [indictor setBackgroundColor:[UIColor redColor]];
    indictor.y = titlesView.height - indictor.height;
    indictor.tag = 0;
    self.indictor = indictor;
    [titlesView addSubview:indictor];
    
    //内部的子标签
    
    NSInteger count = 5;
    for (NSInteger i = 0; i<count; i++) {
        UIButton *btn = [[UIButton alloc]init];
        btn.tag = i+100;
        btn.height = titlesView.height;
        btn.width = titlesView.width*1.0/count;
        btn.x = i*btn.width;
        btn.y = 0;
        UIViewController *vc = self.childViewControllers[i];
        [btn setTitle:vc.title forState:UIControlStateNormal];
        //        [btn layoutIfNeeded];//强制布局
        [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        //点击中的按钮,防止多次被点击.
        [btn setTitleColor:[UIColor redColor] forState:UIControlStateDisabled];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:14]];
        [btn addTarget:self action:@selector(titleClick:) forControlEvents:UIControlEventTouchUpInside];
        [titlesView addSubview:btn];
        
        //默认点击了第一个按钮
        if (i == 0) {
            btn.enabled = NO;
            self.selectedBtn = btn;
            //让按钮内部的label根据文字的内容来计算尺寸
            //            [btn.titleLabel sizeToFit];
            self.indictor.width = [vc.title sizeWithAttributes:@{NSFontAttributeName:btn.titleLabel.font}].width;
            self.indictor.centerX = btn.centerX;
            
        }
    }
    
    [self.view addSubview:titlesView];
}
-(void)titleClick:(UIButton *)btn
{
    //修改按钮状态
    self.selectedBtn.enabled = YES;
    btn.enabled = NO;
    self.selectedBtn = btn;
    
    [UIView animateWithDuration:0.25 animations:^{
        self.indictor.width = btn.titleLabel.width;
        self.indictor.centerX = btn.centerX;
    }];
    //滚动
    CGPoint offset = self.contentView.contentOffset;
    offset.x = (btn.tag-100)*self.contentView.width;
    [self.contentView setContentOffset:offset animated:YES];
}
#pragma mark - 底部的uiscrollview
-(void)setupContentView
{
    //不要自动调整inset
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    UIScrollView *scrollview = [[UIScrollView alloc]init];
    scrollview.frame = self.view.bounds;
    scrollview.delegate = self;
    scrollview.pagingEnabled =  YES;
    [self.view insertSubview:scrollview atIndex:0];
    //滚动的范围
    scrollview.contentSize = CGSizeMake(scrollview.width*self.childViewControllers.count, 0);
    
    self.contentView = scrollview;
    
    //添加第一个控制器的view
    [self scrollViewDidEndScrollingAnimation:self.contentView];
}
#pragma mark - 初始化子控制器
-(void)setupChildViews
{
    LMTopicsViewController *allVC = [[LMTopicsViewController alloc]init];
    allVC.type = LMTopicsTypeAll;
    allVC.title = @"全部";
    [self addChildViewController:allVC];
    
    LMTopicsViewController *audioVC = [[LMTopicsViewController alloc]init];
    audioVC.title = @"视频";
    audioVC.type = LMTopicsTypeVideo;
    [self addChildViewController:audioVC];
    
    LMTopicsViewController *voiceVC = [[LMTopicsViewController alloc]init];
    voiceVC.title = @"声音";
    voiceVC.type = LMTopicsTypeVoice;
    [self addChildViewController:voiceVC];
    
    LMTopicsViewController *pictureVC = [[LMTopicsViewController alloc]init];
    pictureVC.type = LMTopicsTypePicture;
    pictureVC.title = @"图片";
    [self addChildViewController:pictureVC];
    
    LMTopicsViewController *wordVC = [[LMTopicsViewController alloc]init];
    wordVC.type = LMTopicsTypeWord;
    wordVC.title = @"段子";
    [self addChildViewController:wordVC];
}
#pragma mark - scrollView Delegate
- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView
{
    //添加子控制器的view，当前的索引。
    NSInteger index = scrollView.contentOffset.x/scrollView.width;

    //取出自控制器
    UIViewController *vc = self.childViewControllers[index];
    vc.view.x = scrollView.contentOffset.x;
    vc.view.y = 99;
    vc.view.height = scrollView.height;
    [scrollView addSubview:vc.view];
}
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    
    [self scrollViewDidEndScrollingAnimation:scrollView];
    //点击按钮
    NSInteger btnTag = scrollView.contentOffset.x/scrollView.width+100;
    [self titleClick:(UIButton *)[self.titlesView viewWithTag:btnTag]];
    
    //或者“保证titlesView最先添加5个button；
//    NSInteger btnTag = scrollView.contentOffset.x/scrollView.width;
//    [self titleClick:self.titlesView[btnTag]];
}
#pragma mark - 精华推荐按钮
-(void)essenceButtonClick
{
//    LMLogFunc;
    LMRecommendTagsController *tags = [[LMRecommendTagsController alloc]init];
    [self.navigationController pushViewController:tags animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
