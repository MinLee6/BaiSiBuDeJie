//
//  LMCommentViewController.m
//  百思不得姐
//
//  Created by limin on 16/6/29.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMCommentViewController.h"
#import "LMTopicsCell.h"
#import "LMTopicsModel.h"
#import "LMCommentModel.h"
#import <MJRefresh.h>
#import <AFNetworking.h>
#import <MJExtension.h>
#import "LMCommentHeaderView.h"
#import "LMCommentCell.h"
//static NSInteger const LMHeaderLabelTag = 99;
static NSString * const LMCommentCellID= @"commentCell";
@interface LMCommentViewController ()<UITableViewDelegate,UITableViewDataSource>
/** 工具条底部间距*/
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomSpace;
/** 评论的表格*/
@property (weak, nonatomic) IBOutlet UITableView *commentTableView;
/* 热门评论 */
@property(nonatomic,strong)NSArray *hotComment;
/* 最新评论 */
@property(nonatomic,strong)NSMutableArray *latestComment;
/* 保存帖子的top_cmt */
@property(nonatomic,strong)NSArray *savedTop_cmt;
/* 页码 */
@property(nonatomic,assign)NSInteger page;

/** 管理者*/
@property(nonatomic,strong)AFHTTPSessionManager *manager;
/* 点击的行号 */
@property(nonatomic,strong)NSIndexPath *selectedIndex;
@end

@implementation LMCommentViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupBasic];
    
    [self setupHeaderView];
    
    [self setupRefresh];
}
-(AFHTTPSessionManager *)manager
{
    if (!_manager) {
        _manager = [AFHTTPSessionManager manager];
    }
    return _manager;
}
#pragma mark - 基本设置
-(void)setupBasic
{
    self.title = @"评论";
    
    self.navigationItem.rightBarButtonItem = [UIBarButtonItem BarButtonItemWithImage:@"comment_nav_item_share_icon" highlightedImage:@"comment_nav_item_share_icon_click" target:self action:@selector(rightItemBtnClick)];
    
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWillChangeFrame:) name:UIKeyboardWillChangeFrameNotification object:nil];

    //cell的高度设置,ios8开始自动算
    self.commentTableView.estimatedRowHeight = 44;
    //自动尺寸
    self.commentTableView.rowHeight = UITableViewAutomaticDimension;
    
    //背景色
    self.commentTableView.backgroundColor = LMGlobalBg;
    //注册
    [self.commentTableView registerNib:[UINib nibWithNibName:NSStringFromClass([LMCommentCell class]) bundle:nil] forCellReuseIdentifier:LMCommentCellID];
    
    //去掉分割线
    self.commentTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    //内边距
    self.commentTableView.contentInset = UIEdgeInsetsMake(0, 0, LMTopicsCellMargin, 0);
}

-(void)setupHeaderView
{
    //设置header
    UIView *header = [[UIView alloc]init];
    //清空top_cmt
    if(self.topicsComment.top_cmt.count)
    {
        self.savedTop_cmt = self.topicsComment.top_cmt;
        self.topicsComment.top_cmt = nil;
        [self.topicsComment setValue:@0 forKey:@"cellHeight"];
    }
    
    
    //添加cell
    LMTopicsCell *topicsCell = [LMTopicsCell createTopicsCell];
    topicsCell.topicsModel = self.topicsComment;
    topicsCell.size = CGSizeMake(LMScreenWidth, self.topicsComment.cellHeight + LMTopicsCellMargin);
    [header addSubview:topicsCell];
    
    
    //header高度
    header.height = self.topicsComment.cellHeight + LMTopicsCellMargin;
    
    self.commentTableView.tableHeaderView = header;

}
/** 添加刷新控件*/
-(void)setupRefresh
{
    //下拉刷新控件
    self.commentTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadNewComments)];
    [self.commentTableView.mj_header beginRefreshing];
    
    //下拉加载更多
    self.commentTableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreData)];
    self.commentTableView.mj_footer.hidden = YES;
    
}
#pragma mark －请求评论数据
/** 加载更多*/
-(void)loadMoreData
{
    //结束之前的所有请求
    [self.manager.tasks makeObjectsPerformSelector:@selector(cancel)];//调用cancel后，就会到failure块里面。
    
    NSInteger page = self.page+1;
    //请求参数
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    param[@"a"] = @"dataList";
    param[@"c"] = @"comment";
    param[@"data_id"] = self.topicsComment.ID;
    param[@"page"] = @(page);
    LMCommentModel *comment = [self.latestComment lastObject];
    param[@"lastcid"] = comment.ID;
    
    [self.manager GET:@"http://api.budejie.com/api/api_open.php" parameters:param progress:^(NSProgress * _Nonnull downloadProgress) {
        //
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        //说明没有评论数据
        if (![responseObject isKindOfClass:[NSDictionary class]]){
            self.commentTableView.mj_footer.hidden = YES;
            return;
        }
        
        NSArray *newComment = [LMCommentModel mj_objectArrayWithKeyValuesArray:responseObject[@"data"]];
        //最新评论
        [self.latestComment addObjectsFromArray:newComment] ;
        //页码处理
        self.page = page;
        
        //刷新
        [self.commentTableView reloadData];
        
        //控制footer的状态
        NSInteger total = [responseObject[@"total"] integerValue];
        if (self.latestComment.count >= total) {
            //全部加载完毕
            [self.commentTableView.mj_footer endRefreshingWithNoMoreData];
        }else
        {
            //结束刷新状态
            [self.commentTableView.mj_footer endRefreshing];
            
        }

    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [self.commentTableView.mj_footer endRefreshing];
    }];
}
/** 最新数据*/
-(void)loadNewComments
{
    //结束之前的所有请求
    [self.manager.tasks makeObjectsPerformSelector:@selector(cancel)];
    
    //请求参数
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    param[@"a"] = @"dataList";
    param[@"c"] = @"comment";
    param[@"data_id"] = self.topicsComment.ID;
    param[@"hot"] = @"1";
    [self.manager GET:@"http://api.budejie.com/api/api_open.php" parameters:param progress:^(NSProgress * _Nonnull downloadProgress) {
        //
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        //说明没有评论数据
        if (![responseObject isKindOfClass:[NSDictionary class]])
        {
            [self.commentTableView.mj_header endRefreshing];
            return;
        }
        
        //最热评论
        self.hotComment = [LMCommentModel mj_objectArrayWithKeyValuesArray:responseObject[@"hot"]];
        //最新评论
        self.latestComment = [LMCommentModel mj_objectArrayWithKeyValuesArray:responseObject[@"data"]];
        //页码
        self.page = 1;
        //结束刷新状态
        [self.commentTableView.mj_header endRefreshing];
        //刷新
        [self.commentTableView reloadData];
        
        //控制footer的状态
        NSInteger total = [responseObject[@"total"] integerValue];
        if (self.latestComment.count >= total) {
            //全部加载完毕
            [self.commentTableView.mj_footer endRefreshingWithNoMoreData];
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        //
        [self.commentTableView.mj_header endRefreshing];
    }];
}
#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    NSInteger hotContent = self.hotComment.count;
    NSInteger lastetContent = self.latestComment.count;
    
    //显示／隐藏尾部控件（有数据显示，无数据隐藏）
    tableView.mj_footer.hidden = lastetContent == 0;
    
    
    if (hotContent) {//最热评论＋最新评论
        return 2;
    }else if(lastetContent)//最新评论，无最热评论
    {
        return 1;
 
    }
    return 0;//无最新评论，无最热评论
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSInteger hotContent = self.hotComment.count;
    NSInteger lastetContent = self.latestComment.count;
    if (section == 0) {
        
        return hotContent? hotContent : lastetContent;
    }
    return lastetContent;//非第0组
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    LMCommentCell *cell = [tableView dequeueReusableCellWithIdentifier:LMCommentCellID];
    NSArray *temp = [self commentForInSection:indexPath.section];
    LMCommentModel *model = temp[indexPath.row];
    cell.commentModel = model;
    return cell;
}
/** 返回第section的评论数组 */
-(NSArray *)commentForInSection:(NSInteger)section
{
    if (section == 0) {
        return self.hotComment.count?self.hotComment : self.latestComment;
    }
    return self.latestComment;
}
//-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
//{
//    NSInteger hotContent = self.hotComment.count;
//    
//    if (section == 0) {
//        
//        return hotContent? @"最热评论" : @"最新评论";
//    }
//    return @"最新评论";
//}
/**
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    //创建头部
    UIView *header = [[UIView alloc]init];
    header.backgroundColor = LMGlobalBg;
    //创建label
    UILabel *label = [[UILabel alloc]init];
    label.width = 200;
    label.x = LMTopicsCellMargin;
    label.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    label.textColor = LMRGB(67, 67, 67);
    [label setFont:[UIFont systemFontOfSize:12]];
    NSInteger hotContent = self.hotComment.count;
    
    //设置文字
    if (section == 0) {
        
        label.text = hotContent? @"最热评论" : @"最新评论";
    }
    label.text = @"最新评论";
    [header addSubview:label];
    
    
    return label;
}
 */


/**
 * 当header比较多的时候也需要从缓存中获取。
 * 循环利用
 *
 
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    static NSString *headerID = @"headerID";
    //先从缓存池中找header
    UITableViewHeaderFooterView *header = [tableView dequeueReusableHeaderFooterViewWithIdentifier:headerID];
    
    UILabel *label = nil;
    if (!header) {//缓存池中没有，自己创建
        header = [[UITableViewHeaderFooterView alloc]initWithReuseIdentifier:headerID];
        header.contentView.backgroundColor = LMGlobalBg;
        //创建label
        label = [[UILabel alloc]init];
        label.width = 200;
        label.x = LMTopicsCellMargin;
        label.autoresizingMask = UIViewAutoresizingFlexibleHeight;
        label.textColor = LMRGB(67, 67, 67);
        [label setFont:[UIFont systemFontOfSize:12]];
        label.tag = LMHeaderLabelTag;
        [header.contentView addSubview:label];
    }else//从缓存池中取出来的
    {
        label = (UILabel *)[header viewWithTag:LMHeaderLabelTag];
    }
    
    //统一设置label的数据
    NSInteger hotContent = self.hotComment.count;
    //设置文字
    if (section == 0) {
        label.text = hotContent? @"最热评论" : @"最新评论";
    }
    label.text = @"最新评论";
    
    return header;
}
 */
/** 自定义循环利用的headerview */
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    LMCommentHeaderView *header = [LMCommentHeaderView headerViewWithTableView:tableView];
    //统一设置label的数据
    NSInteger hotContent = self.hotComment.count;
    //设置文字
    if (section == 0) {
        header.titleStr = hotContent? @"最热评论" : @"最新评论";
    }else
    {
        header.titleStr = @"最新评论";
    }
    
    
    return header;
}
#pragma mark - 键盘监听事件
-(void)keyboardWillChangeFrame:(NSNotification *)note
{
    CGRect frame = [note.userInfo[UIKeyboardFrameEndUserInfoKey]CGRectValue];
    
    //自定义工具条，距底部的值。
    self.bottomSpace.constant = LMScreenHeight - frame.origin.y;
    
    //动画时间
    CGFloat duration = [note.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    
    [UIView animateWithDuration:duration animations:^{
        [self.view layoutIfNeeded];
    }];
}

#pragma mark - 导航右边点击事件
-(void)rightItemBtnClick
{
    LMLog(@"导航右边被点击");
}
#pragma mark -  <UIScrollViewDelegate>
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [self.view endEditing:YES];
    //隐藏menu
    [[UIMenuController sharedMenuController]setMenuVisible:NO animated:YES];
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //显示UIMenuController
    UIMenuController *menu = [UIMenuController sharedMenuController];
    if (menu.isMenuVisible) {
        //隐藏menu
        [menu setMenuVisible:NO animated:YES];
        return;
    }else
    {
        //被点击的cell
        LMCommentCell *cell = (LMCommentCell *)[tableView cellForRowAtIndexPath:indexPath];
        //出现一个第一个响应者
        [cell becomeFirstResponder];
        
        CGRect rect = CGRectMake(0, cell.bounds.size.height*0.5,cell.bounds.size.width, cell.bounds.size.height*0.5);
        [menu setTargetRect:rect inView:cell];
        [menu setMenuVisible:YES animated:YES];
        
        UIMenuItem *ding = [[UIMenuItem alloc]initWithTitle:@"顶" action:@selector(ding:)];
        UIMenuItem *replay = [[UIMenuItem alloc]initWithTitle:@"回复" action:@selector(replay:)];
        UIMenuItem *report = [[UIMenuItem alloc]initWithTitle:@"举报" action:@selector(report:)];
        menu.menuItems = @[ding,replay,report];
    }
    

}
#pragma mark - UIMenuController处理
-(void)ding:(UIMenuController *)menu
{
    NSLog(@"%s",__func__);
    NSIndexPath *index = [self.commentTableView indexPathForSelectedRow];
}
-(void)replay:(UIMenuController *)menu
{
    NSLog(@"%s",__func__);
}
-(void)report:(UIMenuController *)menu
{
    NSLog(@"%s",__func__);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
    
    //恢复帖子的top_cmt
    if(self.savedTop_cmt)
    {
        self.topicsComment.top_cmt = self.savedTop_cmt;
        [self.topicsComment setValue:@0 forKey:@"cellHeight"];
        
    }
    //取消所有任务
    //    [self.manager.tasks makeObjectsPerformSelector:@selector(cancel)];
    [self.manager invalidateSessionCancelingTasks:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
