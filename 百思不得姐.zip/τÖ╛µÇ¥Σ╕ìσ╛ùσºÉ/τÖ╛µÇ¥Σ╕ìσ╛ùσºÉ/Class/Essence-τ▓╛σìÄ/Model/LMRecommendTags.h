//
//  LMRecommendTags.h
//  百思不得姐
//
//  Created by limin on 16/6/16.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LMRecommendTags : NSObject
/* 图片 */
@property(nonatomic,copy)NSString *image_list;
/* 名字 */
@property(nonatomic,copy)NSString *theme_name;
/* 订阅数 */
@property(nonatomic,assign)NSInteger sub_number;
@end
