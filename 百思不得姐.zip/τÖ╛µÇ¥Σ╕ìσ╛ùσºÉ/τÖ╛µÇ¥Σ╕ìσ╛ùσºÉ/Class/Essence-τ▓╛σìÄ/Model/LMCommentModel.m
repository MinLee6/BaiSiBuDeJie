//
//  LMCommentModel.m
//  百思不得姐
//
//  Created by limin on 16/6/29.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMCommentModel.h"
#import <MJExtension.h>
@implementation LMCommentModel
+(NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{@"ID":@"id"};
}
@end
