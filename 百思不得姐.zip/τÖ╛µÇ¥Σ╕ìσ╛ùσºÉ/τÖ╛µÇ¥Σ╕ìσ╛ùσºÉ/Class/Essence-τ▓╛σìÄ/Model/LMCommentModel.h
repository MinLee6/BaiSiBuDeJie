//
//  LMCommentModel.h
//  百思不得姐
//
//  Created by limin on 16/6/29.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <Foundation/Foundation.h>
@class LMUserModel;
@interface LMCommentModel : NSObject
/* 标识ID */
@property(nonatomic,copy)NSString* ID;
/* 音频文件的时长 */
@property(nonatomic,assign)NSInteger voicetime;
/* 音频文件的路径 */
@property(nonatomic,copy)NSString *voiceuri;
/* 拼论的文字内容 */
@property(nonatomic,copy)NSString *content;
/* 被点赞的人数 */
@property(nonatomic,assign)NSInteger like_count;
/* 用户模型 */
@property(nonatomic,strong)LMUserModel *user;
@end
