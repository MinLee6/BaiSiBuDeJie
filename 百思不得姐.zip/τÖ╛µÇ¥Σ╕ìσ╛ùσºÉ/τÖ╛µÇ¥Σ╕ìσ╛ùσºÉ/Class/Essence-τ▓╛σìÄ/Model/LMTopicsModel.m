//
//  LMTopicsModel.m
//  百思不得姐
//
//  Created by limin on 16/6/21.
//  Copyright © 2016年 limin. All rights reserved.
//帖子

#import "LMTopicsModel.h"
#import "LMCommentModel.h"
#import <MJExtension.h>
#import "LMCommentModel.h"
#import "LMUserModel.h"
@implementation LMTopicsModel
{
    //自己生成下划线变量
    @private
    CGFloat _cellHeight;
}
+(NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{
             @"small_image":@"image0",
             @"middle_image":@"image2",
             @"large_image":@"image1",
             @"ID":@"id"
             };
}
+(NSDictionary *)mj_objectClassInArray
{
//    return @{@"top_cmt":[LMCommentModel class]};
    return @{@"top_cmt":@"LMCommentModel"};
}
-(CGFloat)cellHeight
{
    if (!_cellHeight) {
        CGSize maxSize = CGSizeMake(LMScreenWidth-4*LMTopicsCellMargin, MAXFLOAT);
        //文字y值
        CGFloat textH = [self.text boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14]} context:nil].size.height;
        
        //cell文字部分的高度
        _cellHeight = LMTopicsCellTextY + textH + LMTopicsCellMargin;
    
        //根据段子的类型，来计算cell的高度。
        if (self.type == LMTopicsTypePicture) {//图片帖子
            //图片显示的宽度
            CGFloat pictureW = LMScreenWidth-4*LMTopicsCellMargin;
            //图片显示的高度
            CGFloat pictureH = pictureW *1.0 * self.height / self.width;
            if(pictureH >= LMTopicsCellPictureMaxH)
            {
                pictureH = LMTopicsCellPictureBreakH;
                self.bigPicture = YES;//为大图
            }else
            {
                self.bigPicture = NO;
            }
                
            //计算图片帖子的控件frame。
            CGFloat pictureX = LMTopicsCellMargin;
            CGFloat pictureY = LMTopicsCellTextY + textH + LMTopicsCellMargin;
            _pictureFrame = CGRectMake(pictureX,pictureY,pictureW, pictureH);
            
            //cell图片部分的高度
            _cellHeight += pictureH+LMTopicsCellMargin;
            
        }else if(self.type == LMTopicsTypeVoice)//声音帖子
        {
            //计算声音帖子的控件frame。
            CGFloat voiceX = LMTopicsCellMargin;
            CGFloat voiceY = LMTopicsCellTextY + textH + LMTopicsCellMargin;
            CGFloat voiceW = LMScreenWidth-4*LMTopicsCellMargin;
            CGFloat voiceH = voiceW *1.0 * self.height / self.width;
            _voiceFrame = CGRectMake(voiceX, voiceY, voiceW, voiceH);
            
            //cell图片部分的高度
            _cellHeight += voiceH+LMTopicsCellMargin;
        }else if(self.type == LMTopicsTypeVideo)//视频帖子
        {
            //计算视频帖子的控件frame。
            CGFloat videoX = LMTopicsCellMargin;
            CGFloat videoY = LMTopicsCellTextY + textH + LMTopicsCellMargin;
            CGFloat videoW = LMScreenWidth-4*LMTopicsCellMargin;
            CGFloat videoH = videoW *1.0 * self.height / self.width;
            _videoFrame = CGRectMake(videoX, videoY, videoW, videoH);
            
            //cell图片部分的高度
            _cellHeight += videoH + LMTopicsCellMargin;
        }
        
        //如果有最热评论
        LMCommentModel *cmt = [self.top_cmt firstObject];
        if (cmt) {
            NSString *content = [NSString stringWithFormat:@"%@ : %@",cmt.user.username,cmt.content];
            CGFloat contentH = [content boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:13]} context:nil].size.height;
            //有评论
            _cellHeight += LMTopicsCellMargin + LMTopicsCellTopCmtTitleH + contentH;
        }
        //整体高度
        _cellHeight += LMTopicsCellMargin + LMTopicsCellToolBarH;
        
    }
    
    return _cellHeight;
}

@end
