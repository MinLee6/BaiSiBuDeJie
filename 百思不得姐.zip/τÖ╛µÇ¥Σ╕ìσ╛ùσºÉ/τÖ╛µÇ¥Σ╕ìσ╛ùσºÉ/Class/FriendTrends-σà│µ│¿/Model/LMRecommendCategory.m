//
//  LMRecommendCategory.m
//  百思不得姐
//
//  Created by limin on 16/6/15.
//  Copyright © 2016年 limin. All rights reserved.
//推荐关注 左边的数据模型

#import "LMRecommendCategory.h"
#import <MJExtension.h>
@implementation LMRecommendCategory
-(NSMutableArray *)usersArray
{
    if (!_usersArray) {
        _usersArray = [NSMutableArray array];
    }
    return _usersArray;
}
+(NSString *)mj_replacedKeyFromPropertyName121:(NSString *)propertyName
{
    if ([propertyName isEqualToString:@"ID"]) {
        return @"id";
    }
    return propertyName;
}
@end
