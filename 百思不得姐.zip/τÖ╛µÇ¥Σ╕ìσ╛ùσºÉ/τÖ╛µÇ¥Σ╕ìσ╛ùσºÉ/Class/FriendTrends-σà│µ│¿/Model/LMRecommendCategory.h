//
//  LMRecommendCategory.h
//  百思不得姐
//
//  Created by limin on 16/6/15.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LMRecommendCategory : NSObject
/* 标签id */
@property(nonatomic,assign)NSInteger ID;
/* 此标签下的用户数 */
@property(nonatomic,assign)NSInteger count;
/* 标签名称 */
@property(nonatomic,copy)NSString *name;

/** 这个类别对应的用户数据*/
@property(nonatomic,strong)NSMutableArray *usersArray;
/* 总数 */
@property(nonatomic,assign)NSInteger total;
/* 当前页码 */
@property(nonatomic,assign)NSInteger currentPage;


/* 总页数 */
//@property(nonatomic,assign)NSInteger total_page;

/* 下一页 */
//@property(nonatomic,assign)NSInteger next_page;
@end
