//
//  LMTextField.m
//  百思不得姐
//
//  Created by limin on 16/6/17.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMTextField.h"
#import <objc/runtime.h>
static NSString *LMPlaceholderColor = @"_placeholderLabel.textColor";
@implementation LMTextField
/** 2:修改站位颜色*/
//-(void)drawPlaceholderInRect:(CGRect)rect
//{
//    [self.placeholder drawInRect:CGRectMake(0, 20, rect.size.width, rect.size.height) withAttributes:@{NSForegroundColorAttributeName:[UIColor grayColor],NSFontAttributeName:self.font}];
//}


/**
 *运行时(Runtime)
 *苹果官方一套C语言库
 *能做很多底层操作（比如访问隐藏的成员变量和方法）
 *Ivar:instance varibles（实例变量）
 *数组名是指向一串内存的第一个地址（数组名就是指向首元素的指针）
 */
/** 获取成员变量列表*/
-(void)getIvarName
{
    unsigned int count = 0;
    //拷贝出所有的成员变量的列表
    Ivar *ivars = class_copyIvarList([UITextField class], &count);
    
    for (int i = 0; i<count; i++) {
        //取出成员变量
        //数组名是指向一串内存的第一个地址（数组名就是指向首元素的指针）
        //1:Ivar var = *(ivars + i);
        //2:Ivar var = ivars[i];
        
        Ivar var = ivars[i];
        //打印成员变量名字
//        NSLog(@"%s",ivar_getName(var));
    }

    //释放
    free(ivars);
}
/** 获取属性列表*/
-(void)getProperty
{
    unsigned int count = 0;
    objc_property_t *Property = class_copyPropertyList([UITextField class], &count);
    for (int i = 0; i<count; i++) {
        objc_property_t property = Property[i];
//        LMLog(@"属性：%s  类型:%s",property_getName(property),property_getAttributes(property));
    }
    free(Property);
}
-(void)awakeFromNib
{
    [self getProperty];
    //光标颜色
    self.tintColor = self.textColor;
    //不成为第一响应者
    [self resignFirstResponder];
}
#pragma mark - 当前文本聚焦时会掉用
-(BOOL)becomeFirstResponder
{
    [self setValue:[UIColor whiteColor] forKeyPath:LMPlaceholderColor];
    return [super becomeFirstResponder];
}
#pragma mark - 当前文失去焦点会掉用
-(BOOL)resignFirstResponder
{
    [self setValue:[UIColor grayColor] forKeyPath:LMPlaceholderColor];
     return [super resignFirstResponder];
}
-(void)setPlaceColor:(UIColor *)placeColor
{
    _placeColor = placeColor;
    [self setValue:placeColor forKeyPath:@"_placeholderLabel.textColor"];
}
//-(void)setHighlighted:(BOOL)highlighted
//{
//    [self setValue:[UIColor whiteColor] forKeyPath:LMPlaceholderColor];
//}
@end
