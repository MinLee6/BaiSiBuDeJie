//
//  LMRecommendUserCell.m
//  百思不得姐
//
//  Created by limin on 16/6/15.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMRecommendUserCell.h"
#import "LMRecommendUser.h"
#import <UIImageView+WebCache.h>
@interface LMRecommendUserCell ()
/** 头像*/
@property (weak, nonatomic) IBOutlet UIImageView *headImageView;
/** 昵称*/
@property (weak, nonatomic) IBOutlet UILabel *screenNameLabel;
/** 粉丝数量*/
@property (weak, nonatomic) IBOutlet UILabel *fansCountLabel;
@end

@implementation LMRecommendUserCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
}
#pragma mark - cell赋值
-(void)setUserModel:(LMRecommendUser *)userModel
{
    _userModel = userModel;
    self.screenNameLabel.text = userModel.screen_name;
    NSString *fans_count = nil;
    if (userModel.fans_count < 10000) {
        fans_count = [NSString stringWithFormat:@"%zd人关注",userModel.fans_count];
    }else
    {
        //大于等于1万
        fans_count = [NSString stringWithFormat:@"%.1f万人关注",userModel.fans_count/10000.0];
    }

    self.fansCountLabel.text = fans_count;
    
    [self.headImageView setHeader:userModel.header];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
