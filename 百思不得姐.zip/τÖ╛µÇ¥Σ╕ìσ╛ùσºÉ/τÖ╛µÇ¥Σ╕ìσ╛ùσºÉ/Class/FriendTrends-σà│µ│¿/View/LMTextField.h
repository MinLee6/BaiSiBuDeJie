//
//  LMTextField.h
//  百思不得姐
//
//  Created by limin on 16/6/17.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LMTextField : UITextField
/* 占位颜色 */
@property(nonatomic,strong)UIColor *placeColor;
@end
