//
//  LMRecommendCategoryCell.h
//  百思不得姐
//
//  Created by limin on 16/6/15.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LMRecommendCategory.h"
@interface LMRecommendCategoryCell : UITableViewCell
/* 类别模型 */
@property(nonatomic,strong)LMRecommendCategory *categoryModel;


@end
