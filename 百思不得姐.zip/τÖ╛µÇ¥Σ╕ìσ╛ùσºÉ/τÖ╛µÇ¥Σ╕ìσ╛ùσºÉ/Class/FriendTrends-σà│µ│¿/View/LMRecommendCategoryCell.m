//
//  LMRecommendCategoryCell.m
//  百思不得姐
//
//  Created by limin on 16/6/15.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMRecommendCategoryCell.h"
#import "LMRecommendCategory.h"
@interface LMRecommendCategoryCell()

/** 选中时显示指示器控件*/
@property (weak, nonatomic) IBOutlet UIView *selectedIndicator;

@end
@implementation LMRecommendCategoryCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.backgroundColor = LMRGB(244, 244, 244);
    
    //默认颜色
//    self.textLabel.textColor = LMRGB(78, 78, 78);
    //高亮颜色：选中一个label时，label所有内容高亮状态。
//    self.textLabel.highlightedTextColor = LMRGB(219, 21, 26);

}
-(void)layoutSubviews
{
    [super layoutSubviews];
    //重新调整内部的textlabel的frame
    self.textLabel.y = 2;
    self.textLabel.height = self.contentView.height-4;
}

#pragma mark - 数据模型赋值
-(void)setCategoryModel:(LMRecommendCategory *)categoryModel
{
    _categoryModel = categoryModel;
    self.textLabel.text = categoryModel.name;
}
#pragma mark - cell被选中
//cell被选中，里面的所有子控件都会进入高亮状态。当selection为None，内部不会进入高亮状态。
//可以在这个方法中监听cell选中和取消选中
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    //没有被选中的时候隐藏
    self.selectedIndicator.hidden = !selected;
    self.textLabel.textColor = selected ? LMRGB(219, 21, 26):LMRGB(78, 78, 78);
}
@end
