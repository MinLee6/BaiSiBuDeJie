//
//  LMFriendTrendsViewController.m
//  百思不得姐
//
//  Created by limin on 16/6/14.
//  Copyright © 2016年 limin. All rights reserved.
//
//01:代码换行  xib:option+return
//    self.tipLabel.text = @"快快登陆吧，关注百思最in牛人\n好友动态让你过把瘾儿！\n哦耶～";

//02:self.title相当于self.navigationItem.title和self.tabBarItem.title两个都设置了。

#import "LMFriendTrendsViewController.h"
#import "LMRecommendViewController.h"
#import "LMLoginRegisterController.h"
@interface LMFriendTrendsViewController ()

@end

@implementation LMFriendTrendsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //设置标题
    self.navigationItem.title = @"我的关注";
    
    //左边的导航项
    self.navigationItem.leftBarButtonItem = [UIBarButtonItem BarButtonItemWithImage:@"friendsRecommentIcon" highlightedImage:@"friendsRecommentIcon-click" target:self action:@selector(friendButtonClick)];
    //设置背景色
    self.view.backgroundColor = LMGlobalBg;
    

}
#pragma mark - 好友关注
-(void)friendButtonClick
{
    //打印函数
//    LMLogFunc;
    LMRecommendViewController *recommendVC = [[LMRecommendViewController alloc]init];
    [self.navigationController pushViewController:recommendVC animated:YES];
}
#pragma mark - 登录注册
- (IBAction)loginRegister:(UIButton *)sender {
    LMLoginRegisterController *loginRegister = [[LMLoginRegisterController alloc]init];
    [self presentViewController:loginRegister animated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
