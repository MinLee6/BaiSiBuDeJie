//
//  LMLoginRegisterController.m
//  百思不得姐
//
//  Created by limin on 16/6/16.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMLoginRegisterController.h"
#import "LMTextField.h"
@interface LMLoginRegisterController ()
/** 登录按钮*/
@property (weak, nonatomic) IBOutlet UIButton *loginButton;
/** 手机号*/
@property (weak, nonatomic) IBOutlet LMTextField *phoneTextField;
/** 密码*/
@property (weak, nonatomic) IBOutlet LMTextField *pwdTextField;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *loginViewLeftMergin;

@end

@implementation LMLoginRegisterController

- (void)viewDidLoad {
    [super viewDidLoad];
    //修改占位颜色
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    dict[NSForegroundColorAttributeName] = [UIColor darkGrayColor];
    self.phoneTextField.attributedPlaceholder = [[NSAttributedString alloc]initWithString:@"手机号" attributes:dict];
    
    
}
-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    //1:在plist中加入属性view。。。为NO。2:并加上这句话.
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;

}
#pragma mark - 登录注册
- (IBAction)showLoginOrRegister:(UIButton *)sender
{
    //退出键盘
    [self.view endEditing:YES];
    if (self.loginViewLeftMergin.constant == 0) {
        sender.selected = YES;
        self.loginViewLeftMergin.constant = -self.view.width;
        }else
        {
        sender.selected = NO;
        self.loginViewLeftMergin.constant = 0;
        
    }
    [UIView animateWithDuration:0.5 animations:^{
        [self.view layoutIfNeeded];
    }];
}
#pragma mark - 关闭
- (IBAction)dismissBtnClick:(UIButton *)sender
{
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
    
    [self dismissViewControllerAnimated:YES completion:nil];
}
//#pragma mark - 修改样式
//-(UIStatusBarStyle)preferredStatusBarStyle
//{
//    return UIStatusBarStyleLightContent;
//}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
