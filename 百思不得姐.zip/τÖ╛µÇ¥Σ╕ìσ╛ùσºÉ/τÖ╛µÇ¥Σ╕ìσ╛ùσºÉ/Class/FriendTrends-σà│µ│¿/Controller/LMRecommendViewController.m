//
//  LMRecommendViewController.m
//  百思不得姐
//
//  Created by limin on 16/6/15.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMRecommendViewController.h"
#import <AFNetworking.h>
#import "MBProgressHUD+LM.h"
#import "LMRecommendCategory.h"
#import "MJExtension.h"
#import "LMRecommendCategoryCell.h"
#import "LMRecommendUserCell.h"
#import "LMRecommendUser.h"
#import "MJRefresh.h"

#define LMSelectedCategory self.categorys[self.categoryTableView.indexPathForSelectedRow.row]
@interface LMRecommendViewController ()<UITableViewDelegate,UITableViewDataSource>
/** 左边的类别表格*/
@property (weak, nonatomic) IBOutlet UITableView *categoryTableView;
/** 左边的类别数据*/
@property(nonatomic,strong)NSArray *categorys;

/** 右边的用户表格*/
@property (weak, nonatomic) IBOutlet UITableView *userTableView;

/* 请求参数 */
@property(nonatomic,strong)NSDictionary *params;
/* AFN的请求管理者 */
@property(nonatomic,strong)AFHTTPSessionManager *manager;
@end

@implementation LMRecommendViewController
static NSString *const LMRecommendCategoryID = @"category";
static NSString *const LMRecommendUserID = @"user";
- (void)viewDidLoad {
    [super viewDidLoad];
    //控件的初始化
    [self setupRecommendView];
    
    //添加刷新控件
    [self setupRefresh];
    
    //加载左侧数据
    [self loadCategorys];
}

#pragma mark - 控件的初始化
-(void)setupRecommendView
{
    self.title = @"推荐关注";
    //设置背景色
    self.view.backgroundColor = LMGlobalBg;
    //注册
    [self.categoryTableView registerNib:[UINib nibWithNibName:NSStringFromClass([LMRecommendCategoryCell class]) bundle:nil] forCellReuseIdentifier:LMRecommendCategoryID];
    //注册
    [self.userTableView registerNib:[UINib nibWithNibName:NSStringFromClass([LMRecommendUserCell class]) bundle:nil] forCellReuseIdentifier:LMRecommendUserID];
    //
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.categoryTableView.contentInset = UIEdgeInsetsMake(64, 0, 0, 0);
    self.userTableView.contentInset = UIEdgeInsetsMake(64, 0, 0, 0);
    self.userTableView.rowHeight = 70;
    
}
//添加刷新控件
-(void)setupRefresh
{
    //header
    self.userTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadNewUsers)];
    self.userTableView.mj_header.hidden = NO;
    //footer
    self.userTableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreUser)];
    self.userTableView.mj_footer.hidden = YES;
}
#pragma mark - 加载左侧数据
-(void)loadCategorys
{
    //显示指示器
    [MBProgressHUD showMessage:@"加载中..." toView:self.view];
    //发送请求
    NSDictionary *dict = @{@"a":@"category",@"c":@"subscribe"};
    [self.manager GET:@"http://api.budejie.com/api/api_open.php" parameters:dict progress:^(NSProgress * _Nonnull downloadProgress) {
        //
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        //
//        LMLog(@"%@",responseObject[@"list"]);
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        self.categorys = [LMRecommendCategory mj_objectArrayWithKeyValuesArray:responseObject[@"list"]];
        //刷新表格
        [self.categoryTableView reloadData];
        //默认选中首行
        [self.categoryTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionTop];
        //让用户表格进入下拉刷新状态
        [self.userTableView.mj_header beginRefreshing];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        //
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        [MBProgressHUD showError:@"加载推荐失败"];
    }];
}
#pragma mark - 懒加载
-(AFHTTPSessionManager *)manager
{
    if (!_manager) {
        _manager = [AFHTTPSessionManager manager];
    }
    return _manager;
}

#pragma mark - 加载用户数据
-(void)loadNewUsers
{
    //设置当前页码为1；
    LMRecommendCategory *category = LMSelectedCategory;
    category.currentPage = 1;
    //发送请求给服务器,加载右侧的数据
    NSDictionary *dict = @{@"a":@"list",@"c":@"subscribe",@"category_id":@(category.ID),@"page":@(category.currentPage)};
    self.params = dict;
    
    [self.manager GET:@"http://api.budejie.com/api/api_open.php" parameters:dict progress:^(NSProgress * _Nonnull downloadProgress) {
        //
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        //字典转模型
        NSArray *users = [LMRecommendUser mj_objectArrayWithKeyValuesArray:responseObject[@"list"]];
        //清除所有旧数据
        [category.usersArray removeAllObjects];
        //添加到当前类别的对应的用户数组中
        [category.usersArray addObjectsFromArray:users];
        //设置总数，保存总数
        category.total = [responseObject[@"total"] integerValue];
        

        if (self.params != dict) return;
        
        //刷新数组
        [self.userTableView reloadData];
        //结束刷新
        [self.userTableView.mj_header endRefreshing];
        [self checkFooterState];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        //
        if (self.params != dict)return;
        [MBProgressHUD showError:@"加载推荐失败"];
        //结束刷新
        [self.userTableView.mj_header endRefreshing];
    }];
}
-(void)loadMoreUser
{
    LMRecommendCategory *category = LMSelectedCategory;
    //发送请求给服务器,加载右侧的数据
    //显示指示器
    [MBProgressHUD showMessage:@"加载中..." toView:self.view];
    NSDictionary *dict = @{@"a":@"list",@"c":@"subscribe",@"category_id":@([LMSelectedCategory ID]),@"page":@(++category.currentPage)};
    self.params = dict;
    [self.manager GET:@"http://api.budejie.com/api/api_open.php" parameters:dict progress:^(NSProgress * _Nonnull downloadProgress) {
        //
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        //字典转模型
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        NSArray *users = [LMRecommendUser mj_objectArrayWithKeyValuesArray:responseObject[@"list"]];
        //添加到当前类别的对应的用户数组中
        [category.usersArray addObjectsFromArray:users];

        if (self.params != dict) return;
        //刷新数组
        [self.userTableView reloadData];
        
        [self checkFooterState];
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        //
        if (self.params != dict) return;
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        [MBProgressHUD showError:@"加载推荐失败"];
        [self.userTableView.mj_footer endRefreshing];
    }];

}
#pragma mark - 监测footer
/** 时刻监测footer的状态*/
-(void)checkFooterState
{
    LMRecommendCategory *category = LMSelectedCategory;
    NSInteger count = [LMSelectedCategory usersArray].count;
    //每次刷新右边数据时，都控制footer显示或者隐藏
    self.userTableView.mj_footer.hidden = (count == 0);
    if (count == category.total) {
        [self.userTableView.mj_footer endRefreshingWithNoMoreData];
    }else
    {
        [self.userTableView.mj_footer endRefreshing];
    }
}
#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.categoryTableView) {
        return self.categorys.count;
    }else
    {
        [self checkFooterState];
        return [LMSelectedCategory usersArray].count;
    }
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.categoryTableView) {//左边类别表格
        LMRecommendCategoryCell *cell = [tableView dequeueReusableCellWithIdentifier:LMRecommendCategoryID];
        cell.categoryModel = self.categorys[indexPath.row];
        return cell;
    }else
    {//右边用户表格
        LMRecommendUserCell *cell = [tableView dequeueReusableCellWithIdentifier:LMRecommendUserID];
        LMRecommendCategory *category = LMSelectedCategory;
        cell.userModel = category.usersArray[indexPath.row];
        return cell;
    }

    
    
}
#pragma mark - UITableViewDelegate
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //结束刷新
    [self.userTableView.mj_header endRefreshing];
    [self.userTableView.mj_footer endRefreshing];
    
    if (tableView == self.categoryTableView) {
        
        LMRecommendCategory *category = self.categorys[indexPath.row];
        
        [self.userTableView.mj_footer endRefreshingWithNoMoreData];
        if (category.usersArray.count>0) {
            //显示曾经的数据
            [self.userTableView reloadData];
        }else
        {
            //马上显示category的用户数据。
            [self.userTableView reloadData];
            //发送请求给服务器
            
            //进入下拉刷新状态
            [self.userTableView.mj_header beginRefreshing];
        }

    }
    
    
}
/**
 1.目前只能显示1页数据
 2.重复发送请求
 3.网络慢带来的细节问题
 */
#pragma mark - 控制器销毁
-(void)dealloc
{
    //停止所有操作
    [self.manager.operationQueue cancelAllOperations];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
