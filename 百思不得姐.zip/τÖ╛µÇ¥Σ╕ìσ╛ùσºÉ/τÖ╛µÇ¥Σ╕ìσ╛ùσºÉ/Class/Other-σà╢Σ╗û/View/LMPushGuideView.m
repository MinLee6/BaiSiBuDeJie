//
//  LMPushGuideView.m
//  百思不得姐
//
//  Created by limin on 16/6/17.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMPushGuideView.h"
@interface LMPushGuideView()

@end

@implementation LMPushGuideView
#pragma mark - 创建指示页
+(instancetype)createPushGuideView
{
    return [[NSBundle mainBundle]loadNibNamed:@"LMPushGuideView" owner:self options:nil][0];
}

#pragma mark - 显示
+(void)show
{
    //判断版本号
    NSString *versionKEY = @"CFBundleShortVersionString";
    //获取当前软件的版本号
    NSString *currentVersion = [NSBundle mainBundle].infoDictionary[versionKEY];
    //获取沙盒中存储的版本号
    NSString *sanboxVersion = [[NSUserDefaults standardUserDefaults]stringForKey:versionKEY];
    if (![sanboxVersion isEqualToString:currentVersion]) {
        //创建推送指示
        LMPushGuideView *pushGuideView = [LMPushGuideView createPushGuideView];
        UIWindow *window = [UIApplication sharedApplication].keyWindow;
        pushGuideView.frame = window.bounds;
        [window addSubview:pushGuideView];
        //存储版本号
        [[NSUserDefaults standardUserDefaults]setObject:currentVersion forKey:versionKEY];
        [[NSUserDefaults standardUserDefaults]synchronize];
    }

}
#pragma mark - 关闭
- (IBAction)pushguideBotClick:(UIButton *)sender {
    [self removeFromSuperview];
}
@end
