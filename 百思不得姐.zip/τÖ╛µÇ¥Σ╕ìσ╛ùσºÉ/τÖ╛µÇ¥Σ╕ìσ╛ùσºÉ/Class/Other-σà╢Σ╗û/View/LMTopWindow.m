//
//  LMTopWindow.m
//  百思不得姐
//
//  Created by limin on 16/7/1.
//  Copyright © 2016年 limin. All rights reserved.
//

/**⚠️遇到的问题：添加后，状态栏消失，解决办法：加入plist中属性，View controller-based status bar appearance设置为NO。（即：不让控制器管理状态栏）。同时，下面的方法失效，

 #pragma mark - 修改样式
 -(UIStatusBarStyle)preferredStatusBarStyle
 {
 return UIStatusBarStyleLightContent;
 }

此时：[UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;可以修改整个程序的状态栏样式，如果单独对一个控制器修改，可以在控制器出栈时，改回原来的样式。
*/


#import "LMTopWindow.h"

@implementation LMTopWindow

static UIWindow *window_;

/** 显示顶部的window*/
+(void)show
{
    window_.hidden = NO;
}

/** 隐藏顶部的window*/
+(void)hidden
{
    window_.hidden = YES;
}
+(void)initialize
{
    window_ = [[UIWindow alloc]init];
    window_.frame = CGRectMake(0, 0, LMScreenWidth, 20);
    UIViewController *vc = [[UIViewController alloc] init];
    
    window_.rootViewController = vc;
    window_.backgroundColor = [UIColor clearColor];
    window_.windowLevel = UIWindowLevelAlert;
    [window_ addGestureRecognizer:[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(windowClick)]];
}
#pragma mark - 监听窗口的点击事件
+(void)windowClick
{
    //1.scrollview
    UIWindow *window = [UIApplication sharedApplication].keyWindow;

    [self searchScrollViewInView:window];
    //2.主窗口
}
+(void)searchScrollViewInView:(UIView *)superView
{
    for (UIScrollView *subview in superView.subviews) {
        //得到subview在窗口中的frame。转换坐标系。拿出subview.frame，从subview.superview，转到父控件的坐标系。
        CGRect newFrame = [subview.superview convertRect:subview.frame toView:nil];
        CGRect winBounds = [UIApplication sharedApplication].keyWindow.bounds;
        //        CGRect newFrame1 = [[UIApplication sharedApplication].keyWindow convertRect:subview.frame toView:subview.superview];
        
        //判断一个控件是否真正显示在窗口内。
        BOOL isShowingOnWindow = subview.window == [UIApplication sharedApplication].keyWindow && !subview.isHidden && subview.alpha>0.01 && CGRectIntersectsRect(newFrame, winBounds);
        
        //如果是scrollview。
        if ([subview isKindOfClass:[UIScrollView class]] && isShowingOnWindow) {
            CGPoint offest = subview.contentOffset;
            offest.y = -subview.contentInset.top;
            [subview setContentOffset:offest animated:YES];
        }
        
        //继续查找子控件
        [self searchScrollViewInView:subview];
    }
}
@end
