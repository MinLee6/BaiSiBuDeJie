//
//  LMTabBar.m
//  百思不得姐
//
//  Created by limin on 16/6/14.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMTabBar.h"
#import "LMPublishViewController.h"
@interface LMTabBar()
/* 发布按钮 */
@property(nonatomic,strong)UIButton *publishButton;
@end
@implementation LMTabBar

-(instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        //设置tabbar的背景图片
        [self setBackgroundImage:[UIImage imageNamed:@"tabbar-light"]];
        //添加发布按钮
        UIButton *publishButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [publishButton setBackgroundImage:[UIImage imageNamed:@"tabBar_publish_icon"] forState:UIControlStateNormal];
        [publishButton setBackgroundImage:[UIImage imageNamed:@"tabBar_publish_click_icon"] forState:UIControlStateSelected];
        [publishButton addTarget:self action:@selector(publishClick) forControlEvents:UIControlEventTouchUpInside];
        publishButton.size = publishButton.currentBackgroundImage.size;
        [self addSubview:publishButton];
        _publishButton = publishButton;

    }
    return self;
}
UIWindow *window;
-(void)publishClick
{
    //1:弹出view：可以实现背景半透明。
    LMPublishViewController *publishVC = [[LMPublishViewController alloc]init];
//    UIWindow *window = [UIApplication sharedApplication].keyWindow;
//    publishV.frame = window.bounds;
//    [window addSubview:publishV];
    
    //2:present控制器:不能实现背景半透明。
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:publishVC animated:NO completion:nil];
    
    //3:自定义UIWindow，实现半透明。独立，不会干扰到其他window。
    //窗口级别:UIWindowLevelAlert>UIWindowLevelStatusBar>UIWindowLevelNormal
//    window = [[UIWindow alloc]init];
//    window.frame = [UIScreen mainScreen].bounds;
//    window.backgroundColor = [[UIColor whiteColor]colorWithAlphaComponent:0.5];
//    window.hidden = NO;//直接显示，就是在最上面显示。默认window不显示，隐藏的。
//    window.windowLevel = UIWindowLevelAlert;
    
    
}
-(void)layoutSubviews
{
    [super layoutSubviews];
    //设置发布按钮的frame
    CGFloat tabbarW = self.width;
    CGFloat tabbarH = self.height;
    
    self.publishButton.center = CGPointMake(tabbarW*0.5, tabbarH*0.5);
    //设置其他UIBarbarItem的frame
    CGFloat buttonY = 0;
    CGFloat buttonW = tabbarW*0.2;
    CGFloat buttonH = tabbarH;
    NSInteger index = 0;
    for (UIView *button in self.subviews) {
        
        //01:
//        if (![button isKindOfClass:[UIControl class]] || button == self.publishButton) continue;
        
        //02:
        if (![button isKindOfClass:NSClassFromString(@"UITabBarButton")])continue;
        
        //计算按钮的X值
        CGFloat buttonX = buttonW * (index>1?(index+1):index);
        button.frame = CGRectMake(buttonX, buttonY, buttonW, buttonH);
        //增加索引
        index++;
    }
}
@end
