//
//  LMPushGuideView.h
//  百思不得姐
//
//  Created by limin on 16/6/17.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LMPushGuideView : UIView
/** 创建指示页*/
+(instancetype)createPushGuideView;
/** 显示*/
+(void)show;
@end
