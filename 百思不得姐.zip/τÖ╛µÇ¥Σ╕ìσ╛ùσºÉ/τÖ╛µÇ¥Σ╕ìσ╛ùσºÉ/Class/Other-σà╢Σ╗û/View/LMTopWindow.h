//
//  LMTopWindow.h
//  百思不得姐
//
//  Created by limin on 16/7/1.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LMTopWindow : NSObject
/** 显示顶部的window*/
+(void)show;
/** 隐藏顶部的window*/
+(void)hidden;
@end
