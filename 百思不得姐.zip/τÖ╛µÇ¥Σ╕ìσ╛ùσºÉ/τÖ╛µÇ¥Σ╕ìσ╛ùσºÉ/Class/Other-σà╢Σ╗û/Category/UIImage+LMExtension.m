//
//  UIImage+LMExtension.m
//  百思不得姐
//
//  Created by limin on 16/7/5.
//  Copyright © 2016年 limin. All rights reserved.
//cocos2d 。开启图形上下文（透明）

#import "UIImage+LMExtension.h"

@implementation UIImage (LMExtension)
/** 返回圆形图片*/
-(UIImage *)circleImage
{
    //NO：透明
    UIGraphicsBeginImageContextWithOptions(self.size, NO, 0.0);
    //获得上下文
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    //添加一个圆
    CGRect rect = CGRectMake(0, 0, self.size.width, self.size.height);
    CGContextAddEllipseInRect(ctx, rect);
    //裁剪
    CGContextClip(ctx);
    //将图片画上去
    [self drawInRect:rect];
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return image;
}
@end
