//
//  UIView+LMExtension.h
//  百思不得姐
//
//  Created by limin on 16/6/14.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (LMExtension)
/* size */
@property(nonatomic,assign)CGSize size;
/* 宽度 */
@property(nonatomic,assign)CGFloat width;
/* 高度 */
@property(nonatomic,assign)CGFloat height;
/* x */
@property(nonatomic,assign)CGFloat x;
/* y */
@property(nonatomic,assign)CGFloat y;
/* centerX */
@property(nonatomic,assign)CGFloat centerX;
/* centerY */
@property(nonatomic,assign)CGFloat centerY;
/** 在分类中声明@property，只会生成方法的声明(setter/getter)，不会生成方法的声明和下划线成员变量*/

/** 是否显示在主窗口*/
-(BOOL)isShowingOnKeyWindow;
@end
