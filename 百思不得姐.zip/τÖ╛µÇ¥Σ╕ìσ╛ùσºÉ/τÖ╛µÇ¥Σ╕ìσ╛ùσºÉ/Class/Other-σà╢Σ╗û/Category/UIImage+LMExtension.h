//
//  UIImage+LMExtension.h
//  百思不得姐
//
//  Created by limin on 16/7/5.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (LMExtension)
/** 返回圆形图片*/
-(UIImage *)circleImage;
@end
