//
//  UIBarButtonItem+LMExtension.m
//  百思不得姐
//
//  Created by limin on 16/6/14.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "UIBarButtonItem+LMExtension.h"

@implementation UIBarButtonItem (LMExtension)
+(instancetype)BarButtonItemWithImage:(NSString *)image highlightedImage:(NSString *)highlightedImage target:(id)target action:(SEL)action
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    [button setBackgroundImage:[UIImage imageNamed:highlightedImage] forState:UIControlStateHighlighted];
    button.size = button.currentBackgroundImage.size;
    [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    
    return [[self alloc]initWithCustomView:button];
}
@end
