//
//  NSDate+LMExtension.h
//  百思不得姐
//
//  Created by limin on 16/6/21.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (LMExtension)
/** 比较当前时间和from时间的差值*/
-(NSDateComponents *)deltaFrom:(NSDate *)from;
/** 是否为今年*/
-(BOOL)isThisYear;
/** 是否为今天*/
-(BOOL)isToday;
/** 是否为昨天*/
-(BOOL)isYesterday;
@end
