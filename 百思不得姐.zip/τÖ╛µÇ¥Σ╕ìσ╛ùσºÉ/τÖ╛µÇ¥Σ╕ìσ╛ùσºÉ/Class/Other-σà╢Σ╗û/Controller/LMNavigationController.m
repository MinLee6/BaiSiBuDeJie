//
//  LMNavigationController.m
//  百思不得姐
//
//  Created by limin on 16/6/14.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMNavigationController.h"

@interface LMNavigationController ()

@end

@implementation LMNavigationController
/** 当第一次使用这个类的时候掉用一次*/
+(void)initialize
{
    //设置导航的背景图片
    //[UINavigationBar appearance] 设置所有的导航都是这个背景图
    UINavigationBar *navBar = [UINavigationBar appearance];
    [navBar setBackgroundImage:[UIImage imageNamed:@"navigationbarBackgroundWhite"] forBarMetrics:UIBarMetricsDefault];
    [navBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:20]}];
    //设置item
    UIBarButtonItem *barItem = [UIBarButtonItem appearance];
    
    //normal
    
    NSMutableDictionary *itemArrays = [NSMutableDictionary dictionary];
    itemArrays[NSForegroundColorAttributeName] = [UIColor blackColor];
    itemArrays[NSFontAttributeName] = [UIFont systemFontOfSize:17];
    [barItem setTitleTextAttributes:itemArrays forState:UIControlStateNormal];

    //disable
    
    NSMutableDictionary *itemDisableArrays = [NSMutableDictionary dictionary];
    itemDisableArrays[NSFontAttributeName] = [UIFont systemFontOfSize:17];
    itemDisableArrays[NSForegroundColorAttributeName] = [UIColor lightGrayColor];
    [barItem setTitleTextAttributes:itemDisableArrays forState:UIControlStateDisabled];
//    navBar.tintColor = [UIColor blackColor];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
}
/**
 * 可以在这个方法中拦截所有push进来的控制器
 */
-(void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    //如果push进来的不是第一个控制器
    if (self.childViewControllers.count>0) {
        //设置返回箭头
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setTitle:@"返回" forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn setTitleColor:LMRGB(252, 61, 57) forState:UIControlStateHighlighted];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:16]];
        [btn setImage:[UIImage imageNamed:@"navigationButtonReturn"] forState:UIControlStateNormal];
        [btn setImage:[UIImage imageNamed:@"navigationButtonReturnClick"] forState:UIControlStateHighlighted];
        [btn addTarget:self action:@selector(backVC) forControlEvents:UIControlEventTouchUpInside];
        btn.size = CGSizeMake(70, 30);
        //向左边移动
        btn.contentEdgeInsets = UIEdgeInsetsMake(0, -10, 0, 0);
        //让按钮中的所有内容水平左对齐。
        btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        
        viewController.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:btn];
        //push进来的，将下面的tabbar隐藏掉.
        viewController.hidesBottomBarWhenPushed = YES;
    }
    //这句super的push要放在后面，让viewController可以覆盖上面设置的leftBarButtonItem
    [super pushViewController:viewController animated:animated];
}
#pragma mark - 返回
-(void)backVC
{
    [self popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
