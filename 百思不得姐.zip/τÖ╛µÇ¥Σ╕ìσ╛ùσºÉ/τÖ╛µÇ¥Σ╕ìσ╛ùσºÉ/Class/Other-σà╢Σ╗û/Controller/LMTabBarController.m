//
//  LMTabBarController.m
//  百思不得姐
//
//  Created by limin on 16/6/14.
//  Copyright © 2016年 limin. All rights reserved.
//tabbar会自动渲染

#import "LMTabBarController.h"
#import "LMEssenceViewController.h"
#import "LMNewViewController.h"
#import "LMFriendTrendsViewController.h"
#import "LMMeViewController.h"
#import "LMTabBar.h"
#import "LMNavigationController.h"
@interface LMTabBarController ()<UITabBarControllerDelegate>

@end

@implementation LMTabBarController
/**
 * [UIColor colorWithRed:223.0/255 green:223.0/255 blue:223.0/255 alpha:1.0]
 颜色：
 a-f
 24bit颜色 ：R G B
 * #000000
 * #ff0000
 * #ffff00
 * #ffffff
 
 每个颜色8bit
 
 32bit颜色 ：R G B A
 灰色的特点：RGB一样
 
 */
#pragma mark - 当这个类用到时，只使用一次。
+(void)initialize
{
    //01:保持原来图片的样式，不渲染。
    //    vc01.tabBarItem.selectedImage = [[UIImage imageNamed:@"tabBar_essence_click_icon"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    //02:到Assets资源里面，找到图片，在右边第三个属性里找到Render As，将Default换为Always Image;
    
    
    
    //设置所有Item的统一样式，必须有UI_APPEARANCE_SELECTOR
    //必须方法后面带有UI_APPEARANCE_SELECTOR的方法，都可以通过appearance，统一设置。
    NSMutableDictionary *attrs = [NSMutableDictionary dictionary];
    attrs[NSFontAttributeName] = [UIFont systemFontOfSize:12];
    attrs[NSForegroundColorAttributeName] = [UIColor grayColor];
    
    NSMutableDictionary *selectedAttrs = [NSMutableDictionary dictionary];
    selectedAttrs[NSFontAttributeName] = [UIFont systemFontOfSize:12];
    selectedAttrs[NSForegroundColorAttributeName] = [UIColor darkGrayColor];
    
    //通过appearance，统一设置所有UITabBarItem的文字属性
    UITabBarItem *item = [UITabBarItem appearance];
    [item setTitleTextAttributes:attrs forState:UIControlStateNormal];
    [item setTitleTextAttributes:selectedAttrs forState:UIControlStateSelected];
    
}
#pragma mark - viewDidLoad
- (void)viewDidLoad {
    [super viewDidLoad];
        //添加自控制器
    [self setupChildVC:[[LMEssenceViewController alloc]init] Title:@"精华" image:@"tabBar_essence_icon" selectedImage:@"tabBar_essence_click_icon"];
    [self setupChildVC:[[LMNewViewController alloc]init] Title:@"新帖" image:@"tabBar_new_icon" selectedImage:@"tabBar_new_click_icon"];
    [self setupChildVC:[[LMFriendTrendsViewController alloc]init] Title:@"关注" image:@"tabBar_friendTrends_icon" selectedImage:@"tabBar_friendTrends_click_icon"];
    [self setupChildVC:[[LMMeViewController alloc]initWithStyle:UITableViewStyleGrouped] Title:@"我" image:@"tabBar_me_icon" selectedImage:@"tabBar_me_click_icon"];
    
    
   //更换tabbar:KVC
    [self setValue:[[LMTabBar alloc]init] forKey:@"tabBar"];
    
    
}
#pragma mark - 初始化子控制器
/**
 *初始化子控制器
 */
-(void)setupChildVC:(UIViewController *)vc Title:(NSString *)title image:(NSString *)image selectedImage:(NSString *)selectedImage
{
    //设置文字和图片
    vc.navigationItem.title = title;
    //一设置背景色导致所有的控制器都执行[UIViewController viewDidLoad]
//    vc.view.backgroundColor = [UIColor colorWithRed:223.0/255 green:223.0/255 blue:223.0/255 alpha:1.0];
    vc.tabBarItem.title = title;
    vc.tabBarItem.image = [UIImage imageNamed:image];
    vc.tabBarItem.selectedImage = [UIImage imageNamed:selectedImage];
    
    //包装一个导航控制器。添加导航控制器为tabbarcontroller的子控制器
    LMNavigationController *nav = [[LMNavigationController alloc]initWithRootViewController:vc];
    
    //添加子控制器
    [self addChildViewController:nav];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
