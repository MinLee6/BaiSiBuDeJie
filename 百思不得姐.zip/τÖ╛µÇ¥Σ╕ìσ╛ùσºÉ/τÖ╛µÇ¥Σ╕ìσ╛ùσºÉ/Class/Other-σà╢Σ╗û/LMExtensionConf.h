//
//  LMExtensionConf.h
//  百思不得姐
//
//  Created by limin on 16/6/23.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LMExtensionConf : NSObject

@end
