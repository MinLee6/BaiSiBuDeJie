//
//  LMConst.m
//  百思不得姐
//
//  Created by limin on 16/6/21.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <UIKit/UIKit.h>
/** 精华-所有顶部标题的高度*/
CGFloat const LMTitleViewH = 35;

/** 精华-所有顶部标题的Y*/
CGFloat const LMTitleViewY = 64;

/** 精华-cell-间距*/
CGFloat const LMTopicsCellMargin = 10;
/** 精华-cell-底部工具条*/
CGFloat const LMTopicsCellToolBarH = 35;
/** 精华-cell-文字内容的Y*/
CGFloat const LMTopicsCellTextY = 55;

/** 精华-cell-图片帖子最大高度*/
CGFloat const LMTopicsCellPictureMaxH = 480;
/** 精华-cell-图片帖子超过最大高度就是用250*/
CGFloat const LMTopicsCellPictureBreakH = 250;
/** 精华-cell-最热评论的高度 */
CGFloat const LMTopicsCellTopCmtTitleH = 20;

/** LMUserModel用户模型的性别属性值*/
NSString * const LMUserModelSexMale = @"m";
/** 女*/
NSString * const LMUserModelSexFemale = @"f";

/** UITabBar被选中的通知名字 */
NSString * const LMTabBarDidSelectedNotification = @"LMTabBarDidSelectedNotification";
/** UITabBar被选中的通知-被点击的控制器的index key*/
NSString * const LMSelectedControllerIndexKey = @"LMSelectedControllerIndexKey";
/** UITabBar被选中的通知-被点击的控制器的key*/
NSString * const LMSelectedControllerKey = @"LMSelectedControllerKey";



