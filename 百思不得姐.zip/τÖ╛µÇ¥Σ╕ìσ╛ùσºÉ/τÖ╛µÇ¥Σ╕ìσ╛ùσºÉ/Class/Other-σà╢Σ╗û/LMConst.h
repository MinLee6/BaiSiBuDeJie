//
//  LMConst.h
//  百思不得姐
//
//  Created by limin on 16/6/21.
//  Copyright © 2016年 limin. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef enum {
    LMTopicsTypeAll = 1,
    LMTopicsTypePicture = 10,
    LMTopicsTypeWord = 29,
    LMTopicsTypeVoice = 31,
    LMTopicsTypeVideo = 41
}LMTopicsType;
/** 精华-所有顶部标题的高度*/
UIKIT_EXTERN CGFloat const LMTitleViewH;
/** 精华-所有顶部标题的Y*/
UIKIT_EXTERN CGFloat const LMTitleViewY;
/** 精华-cell-间距*/
UIKIT_EXTERN CGFloat const LMTopicsCellMargin;
/** 精华-cell-底部工具条*/
UIKIT_EXTERN CGFloat const LMTopicsCellToolBarH;
/** 精华-cell-文字内容的Y*/
UIKIT_EXTERN CGFloat const LMTopicsCellTextY;
/** 精华-cell-图片帖子最大高度*/
UIKIT_EXTERN CGFloat const LMTopicsCellPictureMaxH;
/** 精华-cell-图片帖子超过最大高度就是用250*/
UIKIT_EXTERN CGFloat const LMTopicsCellPictureBreakH;
/** 精华-cell-最热评论的高度 */
UIKIT_EXTERN CGFloat const LMTopicsCellTopCmtTitleH;


/** LMUserModel用户模型的性别属性值*/
UIKIT_EXTERN NSString * const LMUserModelSexMale;
/** 女*/
UIKIT_EXTERN NSString * const LMUserModelSexFemale;

/** UITabBar被选中的通知名字 */
UIKIT_EXTERN NSString * const LMTabBarDidSelectedNotification;
/** UITabBar被选中的通知-被点击的控制器的index key*/
UIKIT_EXTERN NSString * const LMSelectedControllerIndexKey;
/** UITabBar被选中的通知-被点击的控制器的key*/
UIKIT_EXTERN NSString * const LMSelectedControllerKey;


