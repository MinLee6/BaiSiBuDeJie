//
//  LMExtensionConf.m
//  百思不得姐
//
//  Created by limin on 16/6/23.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMExtensionConf.h"
#import "LMTopicsModel.h"
#import "LMRecommendCategory.h"
#import <MJExtension.h>
@implementation LMExtensionConf
+(void)initialize
{
    [LMTopicsModel mj_setupReplacedKeyFromPropertyName:^NSDictionary *{
        return @{
                 @"small_image":@"image0",
                 @"middle_image":@"image2",
                 @"large_image":@"image1"
                 };
    }];
    
    [LMRecommendCategory mj_setupReplacedKeyFromPropertyName:^NSDictionary *{
        return @{@"ID":@"id"};
    }];
}
@end
