//
//  LMPlaceholderTextView.m
//  百思不得姐
//
//  Created by limin on 16/7/7.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMPlaceholderTextView.h"
@interface LMPlaceholderTextView()
/* 占位文字label */
@property(nonatomic,strong)UILabel *placeholderLabel;
@end
@implementation LMPlaceholderTextView
-(UILabel *)placeholderLabel
{
    if (!_placeholderLabel) {
        //
        //添加一个用来显示占位文字的label。
        UILabel *placeholderLabel = [[UILabel alloc]init];
        
        placeholderLabel.hidden = NO;
        placeholderLabel.numberOfLines = 0;
        placeholderLabel.x = 4;
        placeholderLabel.y = 7;
        [self addSubview:placeholderLabel];
        _placeholderLabel = placeholderLabel;//setter方法
    }
    return _placeholderLabel;
    
}
-(instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        //垂直方向上，永远有弹簧效果.
        self.alwaysBounceVertical = YES;
        self.font = [UIFont systemFontOfSize:14];
        
        
        
        //默认的占位文字颜色
        self.placeholderColor = [UIColor grayColor];
        //监听文字改变
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(textDidChange) name:UITextViewTextDidChangeNotification object:nil];
        
        
        
        
    }
    return self;
}
/**
 *监听文字改变
 */
-(void)textDidChange
{
    //只要有文字，就隐藏占位文字label
    self.placeholderLabel.hidden = self.hasText;
}
/**
 *更新占位文字的尺寸
 */
-(void)layoutSubviews
{
    [super layoutSubviews];
    //1:
//    CGSize maxSize = CGSizeMake(self.width - 2*self.placeholderLabel.x, MAXFLOAT);
//    self.placeholderLabel.size = [self.placeholder boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:self.font} context:nil].size;


    //2:
    self.placeholderLabel.width = self.width - 2*self.placeholderLabel.x;
    [self.placeholderLabel sizeToFit];
}
/**
 *[self setNeedsDisplay];会在恰当的时候掉用drawRect
 *[self setNeedsLayout];会在恰当的时候掉用layoutSubviews方法.
 */
#pragma mark - 重写setter方法
-(void)setPlaceholderColor:(UIColor *)placeholderColor
{
    _placeholderColor = placeholderColor;
    self.placeholderLabel.textColor = placeholderColor;
}
-(void)setPlaceholder:(NSString *)placeholder
{
    _placeholder = [placeholder copy];
    self.placeholderLabel.text = placeholder;
    [self setNeedsLayout];
}
-(void)setFont:(UIFont *)font
{
    [super setFont:font];
    self.placeholderLabel.font = font;
    [self setNeedsLayout];
}
-(void)setText:(NSString *)text
{
    [super setText:text];
    //只要有文字，就隐藏占位文字label
    [self textDidChange];
}
-(void)setAttributedText:(NSAttributedString *)attributedText
{
    [super setAttributedText:attributedText];
    [self textDidChange];
    
}
-(void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}


@end
