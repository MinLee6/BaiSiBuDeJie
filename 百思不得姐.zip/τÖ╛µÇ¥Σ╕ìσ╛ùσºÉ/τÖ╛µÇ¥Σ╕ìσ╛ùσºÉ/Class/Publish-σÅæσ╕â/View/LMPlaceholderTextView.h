//
//  LMPlaceholderTextView.h
//  百思不得姐
//
//  Created by limin on 16/7/7.
//  Copyright © 2016年 limin. All rights reserved.
//拥有占位文字功能的UITextView

#import <UIKit/UIKit.h>

@interface LMPlaceholderTextView : UITextView
/* 占位文字 */
@property(nonatomic,copy)NSString *placeholder;
/* 占位文字的颜色 */
@property(nonatomic,strong)UIColor *placeholderColor;

@end
