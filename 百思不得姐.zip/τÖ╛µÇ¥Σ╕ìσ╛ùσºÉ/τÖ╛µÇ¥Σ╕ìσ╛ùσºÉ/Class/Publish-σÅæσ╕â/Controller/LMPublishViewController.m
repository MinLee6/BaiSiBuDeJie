//
//  LMPublishViewController.m
//  百思不得姐
//
//  Created by limin on 16/6/24.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMPublishViewController.h"
#import "LMVerticalButton.h"
#import <POP.h>
#import "LMPostWordController.h"
#import "LMNavigationController.h"
#define LMRootView [UIApplication sharedApplication].keyWindow.rootViewController.view
static CGFloat const LMSpringFactor = 8;
@interface LMPublishViewController ()
/* 添加标题 */
@property(nonatomic,strong)UIImageView *sloganView;
@end

@implementation LMPublishViewController

-(void)viewDidLoad
{
    [super viewDidLoad];
    

    //让控制器的view不能被点击

    self.view.userInteractionEnabled = NO;
    //数据
    NSArray *images = @[@"publish-video", @"publish-picture", @"publish-text", @"publish-audio", @"publish-review", @"publish-offline"];
    NSArray *titles = @[@"发视频", @"发图片", @"发段子", @"发声音", @"审帖", @"离线下载"];
    //中间的6个按钮
    CGFloat btnW = 72;
    CGFloat btnH = btnW+30;
    CGFloat btnStartY = (LMScreenHeight - 2*btnH)*0.5;
    int maxCols = 3;
    CGFloat btnStartX = 15;
    CGFloat marginX = (LMScreenWidth - maxCols*btnW - btnStartX*2)/(maxCols-1);
    for (int i = 0; i<images.count; i++) {
        LMVerticalButton *btn = [[LMVerticalButton alloc]init];
        btn.tag = 100+i;
        [btn addTarget:self action:@selector(funcationBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:btn];
        //设置内容
        [btn setTitle:titles[i] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [btn.titleLabel setFont:[UIFont systemFontOfSize:14]];
        [btn setImage:[UIImage imageNamed:images[i]] forState:UIControlStateNormal];
        //设置Frame
        int row = i/maxCols;
        int col = i%maxCols;
        CGFloat btnX = btnStartX + col*(marginX+btnW);
        CGFloat btnEndY = btnStartY + row * btnH;
        CGFloat btnBeginY = btnEndY - LMScreenHeight;
        
        //添加动画:真正改变它的Frame。
        POPSpringAnimation *animation = [POPSpringAnimation animationWithPropertyNamed:kPOPViewFrame];
        animation.fromValue = [NSValue valueWithCGRect:CGRectMake(btnX, btnBeginY, btnW, btnH)];
        animation.toValue = [NSValue valueWithCGRect:CGRectMake(btnX, btnEndY, btnW, btnH)];
        animation.springBounciness = LMSpringFactor;
        animation.springSpeed = LMSpringFactor;
        animation.beginTime = CACurrentMediaTime() + 0.1*i;
        [btn pop_addAnimation:animation forKey:nil];
    }
    //添加标题,标语的动画。
    UIImageView *sloganView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"app_slogan"]];
    [self.view addSubview:sloganView];
    CGFloat sloganEndY = LMScreenHeight * 0.2;
    CGFloat sloganStartY = sloganEndY-LMScreenHeight;
    CGFloat sloganCenterX = LMScreenWidth * 0.5;
    POPSpringAnimation *Ani = [POPSpringAnimation animationWithPropertyNamed:kPOPViewCenter];
    Ani.fromValue = [NSValue valueWithCGPoint:CGPointMake(sloganCenterX, sloganStartY)];
    Ani.toValue = [NSValue valueWithCGPoint:CGPointMake(sloganCenterX, sloganEndY)];
    Ani.beginTime = CACurrentMediaTime()+images.count*0.1;
    Ani.springBounciness = LMSpringFactor;
    Ani.springSpeed = LMSpringFactor;
    [Ani setCompletionBlock:^(POPAnimation *anim, BOOL finished) {
        
        self.view.userInteractionEnabled = YES;
        
//        LMRootView.userInteractionEnabled = YES;//标语动画执行完毕，回复点击东湖
    }];
    [sloganView pop_addAnimation:Ani forKey:nil];
    _sloganView = sloganView;
}
#pragma mark - 取消
/** 
 *取消
 */
- (IBAction)cancelBtnClick:(UIButton *)sender {
    [self cancelWithCompletionBlock:nil];
    
}
/**
 *先执行退出动画，动画完毕后执行completion。
 *
 */
-(void)cancelWithCompletionBlock:(void (^)())completionBlock
{
//    LMRootView.userInteractionEnabled = NO;
    self.view.userInteractionEnabled = NO;
    int beginIndex = 2;
    for (int i = beginIndex; i<self.view.subviews.count; i++) {
        UIView *subview = self.view.subviews[i];
        
        //添加动画:真正改变它的Frame。
        POPBasicAnimation *animation = [POPBasicAnimation animationWithPropertyNamed:kPOPViewCenter];
        //动画的执行节奏:一开始很慢，后面很快。
        //        animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
        CGFloat centerY = subview.centerY+LMScreenHeight;
        animation.toValue = [NSValue valueWithCGPoint:CGPointMake(subview.centerX, centerY)];
        animation.beginTime = CACurrentMediaTime() + 0.1*(i-beginIndex);
        [subview pop_addAnimation:animation forKey:nil];
        
        //标语动画执行完毕，回复点击东湖
        if (i==self.view.subviews.count-1) {
            [animation setCompletionBlock:^(POPAnimation *anim, BOOL finished) {
//                LMRootView.userInteractionEnabled = YES;
                [self dismissViewControllerAnimated:NO completion:nil];
                //执行传进来的completionBlock参数
                if (completionBlock) {
                    completionBlock();
                }
                
            }];
            
        }
        
    }
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self cancelWithCompletionBlock:nil];
}
#pragma mark - 六个按钮点击事件
-(void)funcationBtnClick:(UIButton *)sender
{
    [self cancelWithCompletionBlock:^{
        //传进去的代码，作为completionBlock参数赋值
        if (sender.tag == 102) {//发段子
            LMPostWordController *postWordVC = [[LMPostWordController alloc]init];
            LMNavigationController *postNav = [[LMNavigationController alloc]initWithRootViewController:postWordVC];
            //这里不能使用self来弹出其他控制器，因为self执行了dismiss操作。
            UIViewController *rootVC = [UIApplication sharedApplication].keyWindow.rootViewController;
            [rootVC presentViewController:postNav animated:YES completion:nil];
            
        }
//        switch (sender.tag) {
//            case 100:
//                LMLog(@"发视频");
//                break;
//            case 101:
//                LMLog(@"发图片");
//                break;
//            case 102:
//                
//                break;
//            case 103:
//                LMLog(@"发声音");
//                break;
//            case 104:
//                LMLog(@"审贴");
//                break;
//            case 105:
//                LMLog(@"离线下载");
//                break;
//            default:
//                break;
//        }
    }];
    
}
/**
 *pop和Core Animation的区别
 *1.core animation添加到layer上
 *2.pop的动画能添加到任何对象上
 *3.pop的底层实现并非基于core animation，是基于CADisplaylink。
 {
 POPSpringAnimation:弹簧动画
 POPBasicAnimation:基本动画
 POPDecayAnimation:衰减动画
 }
 *4.core animation的动画仅仅是表象，并不会真正的修改对象的Frame等属性值。
 *5.pop的动画实时修改对象的属性，真正的修改了对象的属性，ect：Frame。
 */
/**
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    
    POPSpringAnimation *animation = [POPSpringAnimation animationWithPropertyNamed:kPOPViewCenter];
    //从当前时间开始，两秒后做动画。
    animation.beginTime = CACurrentMediaTime()+2.0;
    animation.springSpeed = 20;
    animation.springBounciness = 20;
    animation.fromValue = [NSValue valueWithCGPoint:CGPointMake(100, 100)];
    animation.toValue = [NSValue valueWithCGPoint:CGPointMake(200, 200)];
    animation.completionBlock = ^(POPAnimation *anim, BOOL finished){
        
        LMLog(@"-------动画结束-------");
    };
    [self.sloganView pop_addAnimation:animation forKey:nil];
}
 */



@end
