//
//  LMPostWordController.m
//  百思不得姐
//
//  Created by limin on 16/7/7.
//  Copyright © 2016年 limin. All rights reserved.
//

#import "LMPostWordController.h"
#import "LMPlaceholderTextView.h"
@interface LMPostWordController ()<UITextViewDelegate>
/* 文本输入控件 */
@property(nonatomic,strong)LMPlaceholderTextView *textView;
@end

@implementation LMPostWordController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //基本设置
    [self setupNav];
    [self setupTextView];
    
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationItem.rightBarButtonItem.enabled = NO;//默认不能点击
}
-(void)setupTextView
{
    LMPlaceholderTextView *textView = [[LMPlaceholderTextView alloc]init];
    textView.delegate = self;
    textView.frame = self.view.bounds;
    textView.placeholder = @"请输入你需要发表的文字";
    textView.placeholderColor = [UIColor grayColor];
    [self.view addSubview:textView];
    self.textView = textView;
}
-(void)setupNav
{
    self.title = @"发表文字";
    self.view.backgroundColor = LMGlobalBg;
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"取消" style:UIBarButtonItemStyleDone target:self action:@selector(cancelItemClick)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"发表" style:UIBarButtonItemStyleDone target:self action:@selector(postItemClick)];
    
}

#pragma mark - 导航点击事件
-(void)cancelItemClick
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)postItemClick
{
    LMLogFunc;
}
#pragma mark - <UITextViewDelegate>
-(void)textViewDidChange:(UITextView *)textView
{
    self.navigationItem.rightBarButtonItem.enabled = textView.hasText;//有文字才能点击
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
