//
//  LMPostWordController.h
//  百思不得姐
//
//  Created by limin on 16/7/7.
//  Copyright © 2016年 limin. All rights reserved.
//发布文字

#import <UIKit/UIKit.h>

@interface LMPostWordController : UIViewController

@end
